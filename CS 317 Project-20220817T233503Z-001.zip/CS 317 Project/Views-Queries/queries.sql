/* Views */
/* By Paige Thompson */
	
CREATE VIEW PS150_Sessions AS 
SELECT sessions.session_time, sessions.building, sessions.room, tutors.name, tutors.Email
FROM tutors INNER JOIN sessions ON tutors.TutorID = sessions.tutorID
INNER JOIN instructors_by_subject ON sessions.sectionID = instructors_by_subject.sectionID
INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
WHERE subjects.courseNum = 'PS150';

CREATE VIEW PS150_Long_Sessions AS 
SELECT long_sessions.session_time, long_sessions.building, long_sessions.room, tutors.name, tutors.Email
FROM tutors INNER JOIN long_sessions ON tutors.TutorID = long_sessions.tutorID
INNER JOIN instructors_by_subject ON long_sessions.sectionID = instructors_by_subject.sectionID
INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
WHERE subjects.courseNum = 'PS150';

CREATE VIEW PS150_Teachers_and_Tutors AS
SELECT teachers.name as Teacher, subjects.name Subject, tutors.name as Tutor, tutors.Email as Tutor_Email FROM teachers 
INNER JOIN instructors_by_subject 
ON teachers.employeeID = instructors_by_subject.employeeID
INNER JOIN subjects 
ON instructors_by_subject.ClassID = subjects.ClassID
INNER JOIN sessions
ON sessions.sectionID = instructors_by_subject.sectionID
INNER JOIN tutors
ON sessions.tutorID = tutors.tutorID
WHERE subjects.courseNum = 'PS150';

CREATE VIEW Subjects_For_Brandon_Todd AS 
SELECT tutors.name as tutor_name, instructors_by_subject.sectionID, subjects.courseNum, subjects.name as subject_name
FROM subjects INNER JOIN instructors_by_subject ON subjects.classID = instructors_by_subject.classID
INNER JOIN tutors ON instructors_by_subject.tutorID = tutors.tutorID
WHERE tutors.tutorID = 8006782;

CREATE VIEW Subjects_For_Jaffe AS 
SELECT teachers.name as teacher_name, instructors_by_subject.sectionID, subjects.courseNum, subjects.name as subject_name
FROM subjects INNER JOIN instructors_by_subject ON subjects.classID = instructors_by_subject.classID
INNER JOIN teachers ON instructors_by_subject.employeeID = teachers.employeeID
WHERE teachers.employeeID = 7006782;

CREATE VIEW Appointments_For_Jack_Bauer AS 
SELECT appointments.appointmentID, students.name as student_name, tutors.name as tutor_name, appointments.appointment_time, appointments.building,appointments.room
FROM appointments INNER JOIN students 
ON appointments.studentID = students.studentID
INNER JOIN instructors_by_subject ON instructors_by_subject.sectionID = appointments.sectionID
INNER JOIN tutors ON tutors.tutorID = instructors_by_subject.tutorID
WHERE students.name = 'Jack Bauer';

CREATE VIEW Tutors_For_Jaffe AS 
SELECT teachers.name as teacher_name, subjects.courseNum, subjects.name as subject_name, tutors.name as tutor_name
FROM teachers INNER JOIN instructors_by_subject
ON instructors_by_subject.employeeID = teachers.employeeID
INNER JOIN subjects ON subjects.classID = instructors_by_subject.classID
INNER JOIN tutors ON instructors_by_subject.tutorID = tutors.tutorID
WHERE teachers.employeeID = 7006782 GROUP BY subjects.name;

CREATE VIEW Sessions_On_Jan_10 AS 
SELECT long_sessions.session_time, subjects.name as subject_name, tutors.name as tutor_name, long_sessions.building, long_sessions.room
FROM tutors INNER JOIN long_sessions ON tutors.TutorID = long_sessions.tutorID
INNER JOIN instructors_by_subject ON long_sessions.sectionID = instructors_by_subject.sectionID
INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
WHERE long_sessions.session_time = '2021-01-10 19:00:00';

CREATE VIEW Appointments_On_Sept_23 AS 
SELECT appointments.appointment_time, subjects.name as subject_name, tutors.name as tutor_name, students.name as student_name, appointments.building, appointments.room
FROM tutors INNER JOIN appointments ON tutors.TutorID = appointments.tutorID
INNER JOIN instructors_by_subject ON appointments.sectionID = instructors_by_subject.sectionID
INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
INNER JOIN students ON appointments.studentID = students.studentID
WHERE appointments.appointment_time = '2021-09-23 14:00:00';

CREATE VIEW Sessions_in_Building_1 AS 
SELECT long_sessions.building, subjects.name as subject_name, tutors.name as tutor_name, long_sessions.session_time, long_sessions.room
FROM tutors INNER JOIN long_sessions ON tutors.TutorID = long_sessions.tutorID
INNER JOIN instructors_by_subject ON long_sessions.sectionID = instructors_by_subject.sectionID
INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
WHERE long_sessions.building = 'Building 1';

CREATE VIEW Subjects_Covered AS 
SELECT * FROM subjects;

CREATE VIEW Teachers_Covered AS 
SELECT * FROM teachers;

CREATE VIEW Students_Signed_Up AS 
SELECT * FROM students WHERE gradYear > 2021;

DELIMITER //
CREATE PROCEDURE Show_Sessions(IN var1 VARCHAR(50))
BEGIN
    SELECT sessions.session_time, sessions.building, sessions.room, tutors.name, tutors.Email
    FROM tutors INNER JOIN sessions ON tutors.TutorID = sessions.tutorID
    INNER JOIN instructors_by_subject ON sessions.sectionID = instructors_by_subject.sectionID
    INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
    WHERE subjects.courseNum = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Long_Sessions(IN var1 VARCHAR(50))
BEGIN
    SELECT long_sessions.session_time, long_sessions.building, long_sessions.room, tutors.name, tutors.Email
    FROM tutors INNER JOIN long_sessions ON tutors.TutorID = long_sessions.tutorID
    INNER JOIN instructors_by_subject ON long_sessions.sectionID = instructors_by_subject.sectionID
    INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
    WHERE subjects.courseNum = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Class_Teachers_and_Tutors(IN var1 VARCHAR(50))
BEGIN
    SELECT teachers.name as Teacher, subjects.name Subject, tutors.name as Tutor, tutors.Email as Tutor_Email FROM teachers 
    INNER JOIN instructors_by_subject 
    ON teachers.employeeID = instructors_by_subject.employeeID
    INNER JOIN subjects 
    ON instructors_by_subject.ClassID = subjects.ClassID
    INNER JOIN sessions
    ON sessions.sectionID = instructors_by_subject.sectionID
    INNER JOIN tutors
    ON sessions.tutorID = tutors.tutorID
    WHERE subjects.courseNum = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Subjects_For_Tutor(IN var1 INT)
BEGIN
    SELECT tutors.name as tutor_name, instructors_by_subject.sectionID, subjects.courseNum, subjects.name as subject_name
    FROM subjects INNER JOIN instructors_by_subject ON subjects.classID = instructors_by_subject.classID
    INNER JOIN tutors ON instructors_by_subject.tutorID = tutors.tutorID
    WHERE tutors.tutorID = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Subjects_For_Teacher(IN var1 INT)
BEGIN
    SELECT teachers.name as teacher_name, instructors_by_subject.sectionID, subjects.courseNum, subjects.name as subject_name
    FROM subjects INNER JOIN instructors_by_subject ON subjects.classID = instructors_by_subject.classID
    INNER JOIN teachers ON instructors_by_subject.employeeID = teachers.employeeID
    WHERE teachers.employeeID = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Appointments_For_Student(IN var1 VARCHAR(50))
BEGIN
    SELECT appointments.appointmentID, students.name as student_name, tutors.name as tutor_name, appointments.appointment_time, appointments.building,appointments.room
    FROM appointments INNER JOIN students 
    ON appointments.studentID = students.studentID
    INNER JOIN instructors_by_subject ON instructors_by_subject.sectionID = appointments.sectionID
    INNER JOIN tutors ON tutors.tutorID = instructors_by_subject.tutorID
    WHERE students.name = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Tutors_For_Teacher(IN var1 INT)
BEGIN
    SELECT teachers.name as teacher_name, subjects.courseNum, subjects.name as subject_name, tutors.name as tutor_name
    FROM teachers INNER JOIN instructors_by_subject
    ON instructors_by_subject.employeeID = teachers.employeeID
    INNER JOIN subjects ON subjects.classID = instructors_by_subject.classID
    INNER JOIN tutors ON instructors_by_subject.tutorID = tutors.tutorID
    WHERE teachers.employeeID = var1 GROUP BY subjects.name;
END; //

DELIMITER //
CREATE PROCEDURE Show_Sessions_On_DayTime(IN var1 VARCHAR(50))
BEGIN
    SELECT long_sessions.session_time, subjects.name as subject_name, tutors.name as tutor_name, long_sessions.building, long_sessions.room
    FROM tutors INNER JOIN long_sessions ON tutors.TutorID = long_sessions.tutorID
    INNER JOIN instructors_by_subject ON long_sessions.sectionID = instructors_by_subject.sectionID
    INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
    WHERE long_sessions.session_time = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Appointments_On_DayTime(IN var1 VARCHAR(50))
BEGIN
    SELECT appointments.appointment_time, subjects.name as subject_name, tutors.name as tutor_name, students.name as student_name, appointments.building, appointments.room
    FROM tutors INNER JOIN appointments ON tutors.TutorID = appointments.tutorID
    INNER JOIN instructors_by_subject ON appointments.sectionID = instructors_by_subject.sectionID
    INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
    INNER JOIN students ON appointments.studentID = students.studentID
    WHERE appointments.appointment_time = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Sessions_in_Building(IN var1 VARCHAR(50))
BEGIN
    SELECT long_sessions.building, subjects.name as subject_name, tutors.name as tutor_name, long_sessions.session_time, long_sessions.room
    FROM tutors INNER JOIN long_sessions ON tutors.TutorID = long_sessions.tutorID
    INNER JOIN instructors_by_subject ON long_sessions.sectionID = instructors_by_subject.sectionID
    INNER JOIN subjects ON instructors_by_subject.ClassID = subjects.ClassID
    WHERE long_sessions.building = var1;
END; //

DELIMITER //
CREATE PROCEDURE Show_Subjects_Covered()
BEGIN
SELECT * FROM Subjects_Covered;
END; //

DELIMITER //
CREATE PROCEDURE Show_Teachers_Covered()
BEGIN
SELECT * FROM Teachers_Covered;
END; //

DELIMITER //
CREATE PROCEDURE Show_Students_Signed_Up()
BEGIN
SELECT * FROM Students_Signed_Up;
END; //