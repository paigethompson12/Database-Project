
/* By Paige Thompson */

DROP PROCEDURE IF EXISTS Show_Sessions;
DROP PROCEDURE IF EXISTS Show_Long_Sessions;
DROP PROCEDURE IF EXISTS Show_Class_Teachers_and_Tutors;
DROP PROCEDURE IF EXISTS Show_Subjects_For_Tutor;
DROP PROCEDURE IF EXISTS Show_Subjects_For_Teacher;
DROP PROCEDURE IF EXISTS Show_Appointments_For_Student;
DROP PROCEDURE IF EXISTS Show_Tutors_For_Teacher;
DROP PROCEDURE IF EXISTS Show_Sessions_On_DayTime;
DROP PROCEDURE IF EXISTS Show_Appointments_On_DayTime;
DROP PROCEDURE IF EXISTS Show_Sessions_in_Building;
DROP PROCEDURE IF EXISTS Show_Subjects_Covered;
DROP PROCEDURE IF EXISTS Show_Teachers_Covered;
DROP PROCEDURE IF EXISTS Show_Students_Signed_Up;

DROP VIEW IF EXISTS PS150_Sessions;
DROP VIEW IF EXISTS PS150_Long_Sessions;
DROP VIEW IF EXISTS PS150_Teachers_and_Tutors;
DROP VIEW IF EXISTS Subjects_For_Brandon_Todd;
DROP VIEW IF EXISTS Subjects_For_Jaffe;
DROP VIEW IF EXISTS Appointments_For_Jack_Bauer;
DROP VIEW IF EXISTS Tutors_For_Jaffe;
DROP VIEW IF EXISTS Sessions_On_Jan_10;
DROP VIEW IF EXISTS Appointments_On_Sept_23;
DROP VIEW IF EXISTS Sessions_in_Building_1;
DROP VIEW IF EXISTS Subjects_Covered;
DROP VIEW IF EXISTS Teachers_Covered;
DROP VIEW IF EXISTS Students_Signed_Up;

DROP TRIGGER IF EXISTS YearCheck;
DROP TRIGGER IF EXISTS AppointmentsDateCheck;
DROP TRIGGER IF EXISTS LongSessionsDateCheck;
DROP TRIGGER IF EXISTS SessionsDateCheck;

DROP TABLE IF EXISTS tutors;
DROP TABLE IF EXISTS sessions;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS teachers;
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS long_sessions;
DROP TABLE IF EXISTS instructors_by_subject;