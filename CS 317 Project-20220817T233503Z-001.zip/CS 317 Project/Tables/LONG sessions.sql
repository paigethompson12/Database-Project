/* Really LONG Sessions Table */
/* By Paige Thompson and Christina Corliss */
	
DROP TABLE IF EXISTS long_sessions;
	
CREATE TABLE IF NOT EXISTS long_sessions(
	sessionID INT NOT NULL AUTO_INCREMENT,
	tutorID INT NOT NULL,
	sectionID INT NOT NULL,
	session_time DATETIME,
	building VARCHAR(15),
	room VARCHAR(10),
	PRIMARY KEY(sessionID));
	
/* 850 sessions total */	
INSERT INTO long_sessions
	(tutorID, sectionID, session_time, building, room) VALUES
	/* Monday */
	(8076441, 100, '2021-01-10 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-10 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-10 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-10 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-10 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-10 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-10 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-10 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-10 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-10 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-10 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-10 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-10 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-01-11 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-01-11 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-01-11 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-01-11 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-01-11 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-01-11 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-01-11 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-01-11 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-01-11 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-01-11 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-01-11 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-01-11 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-01-11 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-01-11 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-01-11 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-01-12 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-01-12 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-01-12 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-01-12 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-01-12 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-01-12 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-01-12 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-01-12 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-01-12 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-01-13 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-01-13 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-01-13 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-01-13 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-01-13 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-01-13 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-01-13 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-01-13 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-01-13 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-01-13 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-01-13 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-01-13 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-01-13 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-01-17 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-17 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-17 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-17 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-17 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-17 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-17 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-17 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-17 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-17 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-17 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-17 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-17 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-01-18 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-01-18 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-01-18 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-01-18 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-01-18 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-01-18 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-01-18 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-01-18 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-01-18 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-01-18 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-01-18 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-01-18 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-01-18 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-01-18 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-01-18 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-01-19 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-01-19 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-01-19 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-01-19 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-01-19 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-01-19 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-01-19 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-01-19 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-01-19 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-01-20 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-01-20 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-01-20 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-01-20 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-01-20 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-01-20 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-01-20 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-01-20 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-01-20 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-01-20 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-01-20 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-01-20 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-01-20 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-01-24 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-24 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-24 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-24 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-24 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-24 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-24 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-24 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-24 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-24 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-24 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-24 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-24 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-01-25 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-01-25 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-01-25 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-01-25 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-01-25 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-01-25 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-01-25 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-01-25 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-01-25 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-01-25 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-01-25 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-01-25 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-01-25 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-01-25 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-01-25 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-01-26 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-01-26 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-01-26 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-01-26 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-01-26 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-01-26 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-01-26 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-01-26 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-01-26 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-01-27 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-01-27 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-01-27 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-01-27 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-01-27 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-01-27 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-01-27 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-01-27 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-01-27 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-01-27 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-01-27 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-01-27 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-01-27 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-01-31 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-31 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-31 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-31 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-31 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-31 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-31 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-31 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-31 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-31 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-31 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-31 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-31 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-02-01 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-02-01 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-02-01 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-02-01 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-02-01 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-02-01 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-02-01 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-02-01 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-02-01 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-02-01 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-02-01 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-02-01 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-02-01 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-02-01 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-02-01 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-02-02 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-02-02 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-02-02 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-02-02 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-02-02 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-02-02 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-02-02 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-02-02 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-02-02 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-02-03 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-02-03 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-02-03 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-02-03 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-02-03 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-02-03 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-02-03 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-02-03 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-02-03 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-02-03 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-02-03 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-02-03 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-02-03 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-02-07 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-02-07 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-02-07 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-02-07 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-02-07 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-02-07 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-02-07 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-02-07 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-02-07 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-02-07 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-02-07 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-02-07 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-02-07 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-02-08 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-02-08 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-02-08 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-02-08 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-02-08 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-02-08 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-02-08 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-02-08 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-02-08 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-02-08 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-02-08 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-02-08 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-02-08 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-02-08 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-02-08 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-02-09 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-02-09 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-02-09 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-02-09 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-02-09 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-02-09 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-02-09 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-02-09 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-02-09 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-02-10 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-02-10 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-02-10 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-02-10 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-02-10 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-02-10 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-02-10 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-02-10 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-02-10 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-02-10 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-02-10 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-02-10 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-02-10 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-02-14 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-02-14 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-02-14 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-02-14 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-02-14 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-02-14 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-02-14 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-02-14 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-02-14 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-02-14 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-02-14 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-02-14 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-02-14 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-02-15 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-02-15 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-02-15 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-02-15 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-02-15 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-02-15 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-02-15 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-02-15 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-02-15 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-02-15 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-02-15 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-02-15 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-02-15 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-02-15 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-02-15 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-02-16 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-02-16 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-02-16 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-02-16 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-02-16 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-02-16 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-02-16 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-02-16 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-02-16 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-02-17 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-02-17 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-02-17 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-02-17 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-02-17 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-02-17 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-02-17 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-02-17 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-02-17 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-02-17 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-02-17 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-02-17 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-02-17 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-02-21 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-02-21 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-02-21 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-02-21 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-02-21 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-02-21 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-02-21 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-02-21 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-02-21 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-02-21 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-02-21 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-02-21 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-02-21 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-02-22 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-02-22 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-02-22 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-02-22 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-02-22 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-02-22 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-02-22 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-02-22 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-02-22 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-02-22 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-02-22 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-02-22 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-02-22 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-02-22 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-02-22 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-02-23 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-02-23 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-02-23 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-02-23 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-02-23 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-02-23 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-02-23 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-02-23 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-02-23 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-02-24 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-02-24 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-02-24 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-02-24 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-02-24 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-02-24 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-02-24 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-02-24 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-02-24 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-02-24 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-02-24 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-02-24 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-02-24 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-02-28 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-02-28 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-02-28 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-02-28 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-02-28 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-02-28 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-02-28 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-02-28 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-02-28 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-02-28 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-02-28 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-02-28 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-02-28 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-01 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-01 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-01 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-01 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-01 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-01 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-01 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-01 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-01 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-01 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-01 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-01 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-01 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-01 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-01 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-02 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-02 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-02 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-02 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-02 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-02 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-02 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-02 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-02 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-03 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-03 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-03 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-03 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-03 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-03 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-03 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-03 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-03 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-03 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-03 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-03 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-03 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-03-07 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-03-07 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-03-07 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-03-07 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-03-07 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-03-07 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-03-07 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-03-07 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-03-07 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-03-07 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-03-07 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-03-07 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-03-07 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-08 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-08 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-08 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-08 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-08 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-08 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-08 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-08 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-08 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-08 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-08 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-08 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-08 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-08 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-08 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-09 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-09 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-09 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-09 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-09 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-09 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-09 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-09 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-09 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-10 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-10 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-10 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-10 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-10 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-10 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-10 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-10 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-10 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-10 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-10 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-10 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-10 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-03-14 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-03-14 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-03-14 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-03-14 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-03-14 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-03-14 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-03-14 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-03-14 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-03-14 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-03-14 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-03-14 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-03-14 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-03-14 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-15 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-15 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-15 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-15 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-15 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-15 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-15 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-15 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-15 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-15 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-15 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-15 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-15 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-15 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-15 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-16 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-16 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-16 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-16 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-16 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-16 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-16 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-16 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-16 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-17 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-17 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-17 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-17 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-17 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-17 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-17 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-17 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-17 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-17 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-17 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-17 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-17 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-03-21 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-03-21 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-03-21 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-03-21 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-03-21 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-03-21 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-03-21 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-03-21 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-03-21 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-03-21 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-03-21 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-03-21 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-03-21 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-22 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-22 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-22 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-22 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-22 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-22 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-22 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-22 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-22 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-22 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-22 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-22 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-22 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-22 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-22 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-23 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-23 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-23 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-23 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-23 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-23 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-23 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-23 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-23 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-24 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-24 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-24 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-24 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-24 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-24 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-24 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-24 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-24 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-24 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-24 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-24 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-24 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-03-28 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-03-28 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-03-28 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-03-28 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-03-28 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-03-28 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-03-28 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-03-28 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-03-28 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-03-28 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-03-28 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-03-28 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-03-28 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-29 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-29 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-29 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-29 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-29 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-29 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-29 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-29 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-29 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-29 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-29 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-29 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-29 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-29 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-29 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-30 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-30 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-30 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-30 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-30 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-30 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-30 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-30 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-30 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-31 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-31 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-31 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-31 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-31 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-31 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-31 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-31 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-31 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-31 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-31 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-31 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-31 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-04-04 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-04-04 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-04-04 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-04-04 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-04-04 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-04-04 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-04-04 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-04-04 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-04-04 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-04-04 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-04-04 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-04-04 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-04-04 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-04-05 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-04-05 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-04-05 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-04-05 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-04-05 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-04-05 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-04-05 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-04-05 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-04-05 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-04-05 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-04-05 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-04-05 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-04-05 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-04-05 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-04-05 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-04-06 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-04-06 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-04-06 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-04-06 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-04-06 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-04-06 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-04-06 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-04-06 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-04-06 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-04-07 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-04-07 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-04-07 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-04-07 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-04-07 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-04-07 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-04-07 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-04-07 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-04-07 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-04-07 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-04-07 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-04-07 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-04-07 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-04-11 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-04-11 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-04-11 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-04-11 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-04-11 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-04-11 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-04-11 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-04-11 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-04-11 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-04-11 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-04-11 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-04-11 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-04-11 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-04-12 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-04-12 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-04-12 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-04-12 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-04-12 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-04-12 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-04-12 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-04-12 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-04-12 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-04-12 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-04-12 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-04-12 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-04-12 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-04-12 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-04-12 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-04-13 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-04-13 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-04-13 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-04-13 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-04-13 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-04-13 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-04-13 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-04-13 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-04-13 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-04-14 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-04-14 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-04-14 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-04-14 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-04-14 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-04-14 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-04-14 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-04-14 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-04-14 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-04-14 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-04-14 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-04-14 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-04-14 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-04-18 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-04-18 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-04-18 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-04-18 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-04-18 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-04-18 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-04-18 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-04-18 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-04-18 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-04-18 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-04-18 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-04-18 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-04-18 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-04-19 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-04-19 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-04-19 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-04-19 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-04-19 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-04-19 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-04-19 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-04-19 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-04-19 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-04-19 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-04-19 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-04-19 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-04-19 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-04-19 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-04-19 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-04-20 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-04-20 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-04-20 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-04-20 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-04-20 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-04-20 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-04-20 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-04-20 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-04-20 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-04-21 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-04-21 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-04-21 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-04-21 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-04-21 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-04-21 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-04-21 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-04-21 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-04-21 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-04-21 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-04-21 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-04-21 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-04-21 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-04-25 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-04-25 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-04-25 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-04-25 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-04-25 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-04-25 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-04-25 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-04-25 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-04-25 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-04-25 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-04-25 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-04-25 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-04-25 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-04-26 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-04-26 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-04-26 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-04-26 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-04-26 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-04-26 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-04-26 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-04-26 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-04-26 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-04-26 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-04-26 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-04-26 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-04-26 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-04-26 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-04-26 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-04-27 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-04-27 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-04-27 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-04-27 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-04-27 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-04-27 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-04-27 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-04-27 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-04-27 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-04-28 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-04-28 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-04-28 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-04-28 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-04-28 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-04-28 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-04-28 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-04-28 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-04-28 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-04-28 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-04-28 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-04-28 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-04-28 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-05-02 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-05-02 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-05-02 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-05-02 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-05-02 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-05-02 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-05-02 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-05-02 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-05-02 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-05-02 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-05-02 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-05-02 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-05-02 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-05-03 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-05-03 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-05-03 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-05-03 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-05-03 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-05-03 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-05-03 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-05-03 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-05-03 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-05-03 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-05-03 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-05-03 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-05-03 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-05-03 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-05-03 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-05-04 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-05-04 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-05-04 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-05-04 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-05-04 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-05-04 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-05-04 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-05-04 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-05-04 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-05-05 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-05-05 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-05-05 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-05-05 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-05-05 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-05-05 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-05-05 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-05-05 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-05-05 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-05-05 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-05-05 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-05-05 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-05-05 19:00:00', 'Building 4', 'Room 105'); /* 50: 'Carson Yinger' CS118 */
	
	
	
	