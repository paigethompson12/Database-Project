/* Instructors By Subject Table */
/* By Christina Corliss */

DROP TABLE IF EXISTS instructors_by_subject;
	
CREATE TABLE IF NOT EXISTS instructors_by_subject (
	sectionID INT NOT NULL AUTO_INCREMENT,
	classID INT NOT NULL,
	employeeID INT NOT NULL,
	tutorID INT NOT NULL,
	PRIMARY KEY(sectionID)); 

/* 230 sections total */
INSERT INTO instructors_by_subject
	(classID, employeeID, tutorID) VALUES
	/* comment information order is: sectionID, teacher_name, tutor_name, and course_num */
	(2001, 7091381, 8342841), /* 1: 'Scott Post' and 'Alexandra Ralph' -- AE301 */ 
	(2002, 7013084, 8342841), /* 2: 'Radek Glaser' and 'Alexandra Ralph' -- AE318 */
	(2003, 7001223, 8046346), /* 3: 'Ken Anothony Bordingnon' and 'Thomas Dewald' -- AE430 */
	(2004, 7034971, 8000345), /* 4: 'Michael Van Hilst' and 'Alex Santalov' -- CS317 */
	(2005, 7005679, 8000346), /* 5: 'Luis Zapata Rivera' and 'Jake Whitaker' -- CEC320 */
	(2006, 7002347, 8023511), /* 6: 'Joel Schipper' and 'Tyler Stiff' -- CEC220 */
	(2006, 7093529, 8005679), /* 7: 'Dennis Kodimer' and 'Cordaellia Farrell' -- CEC220 */
	(2006, 7093529, 8005679), /* 8: 'Dennis Kodimer' and 'Cordaellia Farrell' -- CEC220 */
	(2006, 7002323, 8006782), /* 9: 'John Matthew Pavlina' and 'Brandon Todd' -- CEC220 */
	(2007, 7002323, 8006782), /* 10: 'John Matthew Pavlina' and 'Brandon Todd' -- CEC223 */
	(2007, 7002323, 8006782), /* 11: 'John Matthew Pavlina' and 'Brandon Todd' -- CEC223 */
	(2007, 7093529, 8005679), /* 12: 'Dennis Kodimer' and 'Cordaellia Farrell' -- CEC223 */
	(2007, 7093529, 8005679), /* 13: 'Dennis Kodimer' and 'Cordaellia Farrell' -- CEC223 */
	(2008, 7006782, 8045647), /* 14: 'Matthew Jaffe' and 'Gabriael Moore' -- CS420 */
	(2009, 7034971, 8002348), /* 15: 'Michael Van Hilst' and 'Issac Juan' -- CE 460 */
	(2010, 7005679, 8056749), /* 16: 'Luis Zapata Rivera' and 'Nathan Kruger' -- CE 470 */
	(2010, 7006782, 8045647), /* 17: 'Matthew Jaffe' and 'Gabriael Moore' -- CE 470 */
	(2011, 7006782, 8000016), /* 18: 'Matthew Jaffe' and 'Ryan Begley' -- CS315 */	
	(2011, 7006782, 8000016), /* 19: 'Matthew Jaffe' and 'Ryan Begley' -- CS315 */
	(2012, 7003454, 8076441), /* 20: 'Heather Marriott' and 'Carson Yinger' -- CS118 */
	(2012, 7003454, 8076441), /* 21: 'Heather Marriott' and 'Carson Yinger' -- CS118 */
	(2013, 7003454, 8003454), /* 22: 'Heather Marriott' and 'Christina Corliss' -- CS125 */
	(2013, 7003454, 8003454), /* 23: 'Heather Marriott' and 'Christina Corliss'-- CS125 */	
	(2014, 7003454, 8003454), /* 24: 'Heather Marriott' and 'Christina Corliss'-- CS225 */
	(2014, 7034971, 8000345), /* 25: 'Michael Van Hilst' and 'Alex Santalov' -- CS225 */
	(2015, 7003454, 8003454), /* 26: 'Heather Marriott' and 'Christina Corliss'-- CS225L */
	(2015, 7034971, 8000345), /* 27: 'Michael Van Hilst' and 'Alex Santalov' -- CS225L */	
	(2016, 7034971, 8000345), /* 28: 'Michael Van Hilst' and 'Alex Santalov' -- CS332 */	
	(2017, 7006782, 8000016), /* 29: 'Matthew Jaffe' and 'Ryan Begley' -- CS432 */	
	(2018, 7006782, 8000016), /* 30: 'Matthew Jaffe' and 'Ryan Begley'-- SE300 */
	(2018, 7006782, 8000016), /* 31: 'Matthew Jaffe' and 'Ryan Begley'-- SE300 */	
	(2019, 7008128, 8054758), /* 32: 'Muna Slewa' and 'Amanda Goodbody'-- ES201 */
	(2020, 7013084, 8054758), /* 33: 'Radek Glaser' and 'Amanda Goodbody'-- ES202 */
	(2021, 7001088, 8054758), /* 34: 'Josef Penaovski' and 'Amanda Goodbody'-- ES204 */
	(2022, 7012311, 8054758), /* 35: 'Brenda Haven' and 'Amanda Goodbody'-- ES205 */
	(2023, 7091381, 8054758), /* 36: 'Scott Post' and 'Amanda Goodbody'-- ES206 */	
	(2024, 7045647, 8000009), /* 37: 'Sameer Abufardeh' and 'Jordan Owens' -- SE310 */
	(2025, 7045647, 8000009), /* 38: 'Sameer Abufardeh' and 'Jordan Owens'-- SE420 */
	(2026, 7098879, 8000009), /* 39: 'Wantanabe Tatsunari' and 'Jordan Owens' -- MA412 */
	(2026, 7098879, 8000009), /* 40: 'Wantanabe Tatsunari' and 'Jordan Owens' -- MA412 */	
	(2027, 7002323, 8056760), /* 41: 'John Matthew Pavlina' and 'Brian Zelt' -- EE335 */
	(2027, 7002323, 8056760), /* 42: 'John Matthew Pavlina' and 'Brian Zelt' -- EE335 */
	(2027, 7002347, 8056761), /* 43: 'Joel Schipper' and 'Hayden Roszell' -- EE335 */
	(2027, 7002347, 8056761), /* 44: 'Joel Schipper' and 'Hayden Roszell' -- EE335 */
	(2027, 7012431, 8000346), /* 45: 'Ahmed Sulyman' and 'Jake Whitaker' -- EE335 */
	(2027, 7012431, 8000346), /* 46: 'Ahmed Sulyman' and 'Jake Whitaker' -- EE335 */	
	(2028, 7002191, 8056760), /* 47: 'John Edward Post, Jr.' and 'Brian Zelt'-- EE336 */
	(2028, 7002191, 8056760), /* 48: 'John Edward Post, Jr.' and 'Brian Zelt'-- EE336 */
	(2028, 7023483, 8056761), /* 49: 'Robert Olive' and 'Hayden Roszell' -- EE336 */
	(2028, 7023483, 8056761), /* 50: 'Robert Olive' and 'Hayden Roszell' -- EE336 */
	(2028, 7023483, 8056761), /* 51: 'Robert Olive' and 'Hayden Roszell' -- EE336 */
	(2028, 7023483, 8056761), /* 52: 'Robert Olive' and 'Hayden Roszell' -- EE336 */
	(2028, 7032942, 8000346), /* 53: 'John Sevic' and 'Jake Whitaker' -- EE336 */
	(2028, 7032942, 8000346), /* 54: 'John Sevic' and 'Jake Whitaker' -- EE336 */
	(2028, 7048258, 8045814), /* 55: 'Seth McNeill' and 'Benjamin Sheldon' -- EE336 */
	(2028, 7048258, 8045814), /* 56: 'Seth McNeill' and 'Benjamin Sheldon' -- EE336 */	
	(2029, 7056760, 8045814), /* 57: 'Jules Yimga' and 'Benjamin Sheldon' -- EC225 */
	(2029, 7056760, 8045814), /* 58: 'Jules Yimga' and 'Benjamin Sheldon' -- EC225 */	
	(2030, 7023511, 8002385), /* 59: 'Kelly Lambert' and 'Nathan Burk' -- HU330 */
	(2030, 7023511, 8002385), /* 60: 'Kelly Lambert' and 'Nathan Burk' -- HU330 */
	(2030, 7023511, 8002385), /* 61: 'Kelly Lambert' and 'Nathan Burk' -- HU330 */
	(2030, 7032894, 8002347), /* 62: 'Michael McClure' and 'Angel Appelzoller' -- HU330 */
	(2030, 7032894, 8002347), /* 63: 'Michael McClure' and 'Angel Appelzoller' -- HU330 */
	(2030, 7032894, 8002347), /* 64: 'Michael McClure' and 'Angel Appelzoller' -- HU330 */
	(2030, 7019412, 8002348), /* 65: 'Joshua Sullins' and 'Issac Juan' -- HU330 */
	(2030, 7019412, 8002348), /* 66: 'Joshua Sullins' and 'Issac Juan' -- HU330 */
	(2030, 7019412, 8002348), /* 67: 'Joshua Sullins' and 'Issac Juan' -- HU330 */
	(2031, 7056761, 8002385), /* 68: 'Michele Zanolin' and 'Nathan Burk' -- PS250 */
	(2031, 7056761, 8002385), /* 69: 'Michele Zanolin' and 'Nathan Burk' -- PS250 */
	(2031, 7034858, 8002347), /* 70: 'Timothy Callahan' and 'Angel Appelzoller' -- PS250 */
	(2031, 7034858, 8002347), /* 71: 'Timothy Callahan' and 'Angel Appelzoller' -- PS250 */	
	(2032, 7006782, 8000016), /* 72: 'Matthew Jaffe' and 'Ryan Begley' -- SE320 */
	(2033, 7002323, 8002348), /* 73: 'John Matthew Pavlina' and 'Issac Juan' -- EGR101 */
	(2033, 7002323, 8002348), /* 74: 'John Matthew Pavlina' and 'Issac Juan' -- EGR101 */	
	(2033, 7032841, 8056749), /* 75: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */
	(2033, 7032841, 8056749), /* 76: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */
	(2033, 7032841, 8056749), /* 77: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */
	(2033, 7032841, 8056749), /* 78: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */
	(2033, 7032841, 8056749), /* 79: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */	
	(2034, 7091283, 8034660), /* 80: 'Susan Rauch' and 'Katie Sugiyama' -- COM221 */
	(2034, 7091283, 8034660), /* 81: 'Susan Rauch' and 'Katie Sugiyama' -- COM221 */
	(2034, 7091283, 8034660), /* 82: 'Susan Rauch' and 'Katie Sugiyama' -- COM221 */
	(2034, 7023841, 8076441), /* 83: 'Mary Beck' and 'Carson Yinger' -- COM221 */
	(2034, 7023841, 8076441), /* 84: 'Mary Beck' and 'Carson Yinger' -- COM221 */
	(2034, 7023841, 8076441), /* 85: 'Mary Beck' and 'Carson Yinger' -- COM221 */
	(2034, 7012318, 8007844), /* 86: 'Eric Kumpf' and 'Sarah Chinn' -- COM221 */
	(2034, 7012318, 8007844), /* 87: 'Eric Kumpf' and 'Sarah Chinn' -- COM221 */
	(2034, 7012318, 8007844), /* 88: 'Eric Kumpf' and 'Sarah Chinn' -- COM221 */	
	(2035, 7002191, 8002347), /* 89: 'John Edward Post, Jr.' and 'Angel Appelzoller' -- UNIV101 */
	(2035, 7083405, 8002349), /* 90: 'Brent Spencer' and 'Caleb Loomis' -- UNIV101 */
	(2035, 7083405, 8002349), /* 91: 'Brent Spencer' and 'Caleb Loomis' -- UNIV101 */
	(2035, 7083405, 8002349), /* 92: 'Brent Spencer' and 'Caleb Loomis' -- UNIV101 */
	(2035, 7083405, 8002349), /* 93: 'Brent Spencer' and 'Caleb Loomis' -- UNIV101 */
	(2035, 7093467, 8008465), /* 94: 'Michelle Elghardgui' and 'Hunter Nudson' -- UNIV101 */
	(2035, 7093467, 8008465), /* 95: 'Michelle Elghardgui' and 'Hunter Nudson' -- UNIV101 */
	(2035, 7093467, 8008465), /* 96: 'Michelle Elghardgui' and 'Hunter Nudson' -- UNIV101 */	
	(2036, 7002342, 8056749), /* 97: 'Lara Ismert' and 'Nathan Kruger' -- MA225 */
	(2036, 7002342, 8056749), /* 98: 'Lara Ismert' and 'Nathan Kruger' -- MA225 */
	(2037, 7002131, 8034660), /* 99: 'Elliott Bryner' and 'Katie Sugiyama' -- ME309 */	
	(2038, 7002141, 8076441), /* 100: 'Elizabeth Gretarsson' and 'Carson Yinger' -- PS150 */
	(2038, 7034893, 8149204), /* 101: 'William MacKunis' and 'Courtney Nelson' -- PS150 */
	(2038, 7034893, 8149204), /* 102: 'William MacKunis' and 'Courtney Nelson' -- PS150 */
	(2038, 7034893, 8149204), /* 103: 'William MacKunis' and 'Courtney Nelson' -- PS150 */
	(2038, 7082609, 8095493), /* 104: 'Tomomi Otani' and 'Joshua Parmenter' -- PS150 */
	(2038, 7082609, 8095493), /* 105: 'Tomomi Otani' and 'Joshua Parmenter' -- PS150 */
	(2038, 7082609, 8095493), /* 106: 'Tomomi Otani' and 'Joshua Parmenter' -- PS150 */
	(2038, 7082609, 8095493), /* 107: 'Tomomi Otani' and 'Joshua Parmenter' -- PS150 */
	(2038, 7034853, 8009543), /* 108: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7034853, 8009543), /* 109: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7034853, 8009543), /* 110: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7034853, 8009543), /* 111: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7034853, 8009543), /* 112: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7084596, 8002355), /* 113: 'Bryan Armentrout' and 'Jacob Hindmarsh' -- PS150 */
	(2038, 7084596, 8002355), /* 114: 'Bryan Armentrout' and 'Jacob Hindmarsh' -- PS150 */
	(2038, 7084596, 8002355), /* 115: 'Bryan Armentrout' and 'Jacob Hindmarsh' -- PS150 */
	(2038, 7084596, 8002355), /* 116: 'Bryan Armentrout' and 'Jacob Hindmarsh' -- PS150 */	
	(2038, 7095832, 8054758), /* 117: 'Byonghoon Seo' and 'Amanda Goodbody'-- PS150 */
	(2038, 7095832, 8054758), /* 118: 'Byonghoon Seo' and 'Amanda Goodbody'-- PS150 */
	(2038, 7095832, 8054758), /* 119: 'Byonghoon Seo' and 'Amanda Goodbody'-- PS150 */
	(2038, 7095832, 8054758), /* 120: 'Byonghoon Seo' and 'Amanda Goodbody'-- PS150 */
	(2038, 7069403, 8000346), /* 121: 'Dan Maronde' and 'Jake Whitaker' -- PS150 */
	(2038, 7069403, 8000346), /* 122: 'Dan Maronde' and 'Jake Whitaker' -- PS150 */
	(2038, 7069403, 8000346), /* 123: 'Dan Maronde' and 'Jake Whitaker' -- PS150 */
	(2038, 7069403, 8000346), /* 124: 'Dan Maronde' and 'Jake Whitaker' -- PS150 */
	(2039, 7093284, 8046346), /* 125: 'Padraig Houlahan' and 'Thomas Dewald' -- PS160 */
	(2039, 7093284, 8046346), /* 126: 'Padraig Houlahan' and 'Thomas Dewald' -- PS160 */
	(2039, 7093284, 8046346), /* 127: 'Padraig Houlahan' and 'Thomas Dewald' -- PS160 */
	(2039, 7093284, 8046346), /* 128: 'Padraig Houlahan' and 'Thomas Dewald' -- PS160 */
	(2039, 7034858, 8034971), /* 129: 'Timothy Callahan' and 'Paige Thompson' -- PS160 */
	(2039, 7034858, 8034971), /* 130: 'Timothy Callahan' and 'Paige Thompson' -- PS160 */
	(2039, 7034858, 8034971), /* 131: 'Timothy Callahan' and 'Paige Thompson' -- PS160 */
	(2039, 7034858, 8034971), /* 132: 'Timothy Callahan' and 'Paige Thompson' -- PS160 */
	(2039, 7093243, 8023511), /* 133: 'Brian Rachford and 'Tyler Stiff' -- PS160 */
	(2039, 7093243, 8023511), /* 134: 'Brian Rachford and 'Tyler Stiff' -- PS160 */
	(2039, 7093243, 8023511), /* 135: 'Brian Rachford and 'Tyler Stiff' -- PS160 */
	(2039, 7093243, 8023511), /* 136: 'Brian Rachford and 'Tyler Stiff' -- PS160 */
	(2039, 7079742, 8000345), /* 137: 'Quentin Bailey' and 'Alex Santalov' -- PS160 */
	(2039, 7079742, 8000345), /* 138: 'Quentin Bailey' and 'Alex Santalov' -- PS160 */
	(2039, 7079742, 8000345), /* 139: 'Quentin Bailey' and 'Alex Santalov' -- PS160 */
	(2039, 7079742, 8000345), /* 140: 'Quentin Bailey' and 'Alex Santalov' -- PS160 */
	(2040, 7000345, 8003454), /* 141: 'Christopher Briggs' and 'Christina Corliss' -- MA241 */
	(2040, 7000345, 8003454), /* 142: 'Christopher Briggs' and 'Christina Corliss' -- MA241 */
	(2040, 7000345, 8003454), /* 143: 'Christopher Briggs' and 'Christina Corliss' -- MA241 */
	(2040, 7098353, 8005679), /* 144: 'Cameron Williams' and 'Cordaellia Farrell' -- MA241 */
	(2040, 7098353, 8005679), /* 145: 'Cameron Williams' and 'Cordaellia Farrell' -- MA241 */
	(2040, 7098353, 8005679), /* 146: 'Cameron Williams' and 'Cordaellia Farrell' -- MA241 */
	(2040, 7094480, 8007844), /* 147: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */	
	(2040, 7094480, 8007844), /* 148: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */	
	(2040, 7094480, 8007844), /* 149: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */
	(2040, 7094480, 8007844), /* 150: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */	
	(2040, 7094480, 8007844), /* 151: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */	
	(2040, 7094480, 8007844), /* 152: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */
	(2041, 7034501, 8094569), /* 153: 'Jian Cheng' and 'Sarah Reiter' -- MA242 */
	(2041, 7034501, 8094569), /* 154: 'Jian Cheng' and 'Sarah Reiter' -- MA242 */	
	(2041, 7034501, 8094569), /* 155: 'Jian Cheng' and 'Sarah Reiter' -- MA242 */	
	(2041, 7034501, 8094569), /* 156: 'Jian Cheng' and 'Sarah Reiter' -- MA242 */		
	(2041, 7039883, 8043092), /* 157: 'Angelynn Alvarez' and 'Hamad Aloud' -- MA242 */
	(2041, 7039883, 8043092), /* 158: 'Angelynn Alvarez' and 'Hamad Aloud' -- MA242 */
	(2041, 7039883, 8043092), /* 159: 'Angelynn Alvarez' and 'Hamad Aloud' -- MA242 */
	(2041, 7039883, 8043092), /* 160: 'Angelynn Alvarez' and 'Hamad Aloud' -- MA242 */
	(2041, 7003235, 8092341), /* 161: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7003235, 8092341), /* 162: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7003235, 8092341), /* 163: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7003235, 8092341), /* 164: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7003235, 8092341), /* 165: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7023408, 8014934), /* 166: 'Dean Holbrook' and 'Ruth Avila' -- MA242 */	
	(2041, 7023408, 8014934), /* 167: 'Dean Holbrook' and 'Ruth Avila' -- MA242 */
	(2041, 7023408, 8014934), /* 168: 'Dean Holbrook' and 'Ruth Avila' -- MA242 */
	(2041, 7023408, 8014934), /* 169: 'Dean Holbrook' and 'Ruth Avila' -- MA242 */
	(2041, 7029026, 8013495), /* 170: 'Edward Poon' and 'Eric Babcock' -- MA242 */
	(2041, 7029026, 8013495), /* 171: 'Edward Poon' and 'Eric Babcock' -- MA242 */
	(2041, 7029026, 8013495), /* 172: 'Edward Poon' and 'Eric Babcock' -- MA242 */
	(2041, 7098353, 8034929), /* 173: 'Cameron Williams' and 'Andrew Blankenship' -- MA242 */
	(2041, 7098353, 8034929), /* 174: 'Cameron Williams' and 'Andrew Blankenship' -- MA242 */
	(2041, 7098353, 8034929), /* 175: 'Cameron Williams' and 'Andrew Blankenship' -- MA242 */
	(2041, 7002342, 8091080), /* 176: 'Lara Ismert' and 'Georgiy Bondar' -- MA242 */
	(2041, 7002342, 8091080), /* 177: 'Lara Ismert' and 'Georgiy Bondar' -- MA242 */
	(2041, 7002342, 8091080), /* 178: 'Lara Ismert' and 'Georgiy Bondar' -- MA242 */
	(2042, 7098879, 8003461), /* 179: 'Wantanabe Tatsunari' and 'Bradyn Braithwaite' -- MA243 */
	(2042, 7098879, 8003461), /* 180: 'Wantanabe Tatsunari' and 'Bradyn Braithwaite' -- MA243 */
	(2042, 7098879, 8003461), /* 181: 'Wantanabe Tatsunari' and 'Bradyn Braithwaite' -- MA243 */
	(2042, 7090319, 8014901), /* 182: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 183: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 184: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 185: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 186: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 187: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 188: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 189: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 190: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2043, 7082343, 8030510), /* 191: 'Brent Soile' and 'Ashleigh Cook' -- MA345 */
	(2043, 7082343, 8030510), /* 192: 'Brent Soile' and 'Ashleigh Cook' -- MA345 */
	(2043, 7082343, 8030510), /* 193: 'Brent Soile' and 'Ashleigh Cook' -- MA345 */
	(2043, 7082343, 8030510), /* 194: 'Brent Soile' and 'Ashleigh Cook' -- MA345 */
	(2043, 7090319, 8023511), /* 195: 'Hisaya Tsutsui' and 'Tyler Stiff' -- MA345 */
	(2043, 7090319, 8023511), /* 196: 'Hisaya Tsutsui' and 'Tyler Stiff' -- MA345 */
	(2043, 7090319, 8023511), /* 197: 'Hisaya Tsutsui' and 'Tyler Stiff' -- MA345 */
	(2043, 7090319, 8023511), /* 198: 'Hisaya Tsutsui' and 'Tyler Stiff' -- MA345 */
	(2043, 7029026, 8013495), /* 199: 'Edward Poon' and 'Eric Babcock' -- MA345 */
	(2043, 7029026, 8013495), /* 200: 'Edward Poon' and 'Eric Babcock' -- MA345 */
	(2043, 7029026, 8013495), /* 201: 'Edward Poon' and 'Eric Babcock' -- MA345 */
	(2043, 7029026, 8013495), /* 202: 'Edward Poon' and 'Eric Babcock' -- MA345 */
	(2044, 7012399, 8023490), /* 203: 'John Sevic' and 'Cortes Crawford' --  EGR115 */
	(2044, 7012399, 8023490), /* 204: 'John Sevic' and 'Cortes Crawford' --  EGR115 */
	(2044, 7012399, 8023490), /* 205: 'John Sevic' and 'Cortes Crawford' --  EGR115 */
	(2044, 7029321, 8013840), /* 206: 'Shigeo Hayashibara' and 'Chase Davis' --  EGR115 */
	(2044, 7029321, 8013840), /* 207: 'Shigeo Hayashibara' and 'Chase Davis' --  EGR115 */
	(2044, 7029321, 8013840), /* 208: 'Shigeo Hayashibara' and 'Chase Davis' --  EGR115 */
	(2044, 7002347, 8003454), /* 209: 'Joel Schipper' and 'Christina Corliss' --  EGR115 */
	(2044, 7002347, 8003454), /* 210: 'Joel Schipper' and 'Christina Corliss' --  EGR115 */
	(2044, 7002347, 8003454), /* 211: 'Joel Schipper' and 'Christina Corliss' --  EGR115 */
	(2044, 7012347, 8013481), /* 212: 'Atanu Halder' and 'Spencer Davis' --  EGR115 */
	(2044, 7012347, 8013481), /* 213: 'Atanu Halder' and 'Spencer Davis' --  EGR115 */
	(2044, 7012347, 8013481), /* 214: 'Atanu Halder' and 'Spencer Davis' --  EGR115 */
	(2044, 7012347, 8013481), /* 215: 'Atanu Halder' and 'Spencer Davis' --  EGR115 */
	(2045, 7003491, 8094987), /* 216: 'Hadi Ali' and 'Kate Delany' --  EGR200 */
	(2045, 7003491, 8094987), /* 217: 'Hadi Ali' and 'Kate Delany' --  EGR200 */
	(2045, 7003491, 8094987), /* 218: 'Hadi Ali' and 'Kate Delany' --  EGR200 */
	(2045, 7003491, 8094987), /* 219: 'Hadi Ali' and 'Kate Delany' --  EGR200 */
	(2045, 7023911, 8058210), /* 220: 'Joseph Smith' and 'Andrew Erickson' --  EGR200 */
	(2045, 7023911, 8058210), /* 221: 'Joseph Smith' and 'Andrew Erickson' --  EGR200 */
	(2045, 7023911, 8058210), /* 222: 'Joseph Smith' and 'Andrew Erickson' --  EGR200 */
	(2045, 7023911, 8058210), /* 223: 'Joseph Smith' and 'Andrew Erickson' --  EGR200 */
	(2046, 7083210, 8342841), /* 224: 'Jesse Chiu' and 'Alexandra Ralph' -- CS213 */
	(2046, 7083210, 8342841), /* 225: 'Jesse Chiu' and 'Alexandra Ralph' -- CS213 */
	(2047, 7083210, 8342841), /* 226: 'Jesse Chiu' and 'Alexandra Ralph' -- CI119 */
	(2047, 7083210, 8342841), /* 227: 'Jesse Chiu' and 'Alexandra Ralph' -- CI119 */
	(2048, 7083210, 8034971), /* 228: 'Jesse Chiu' and 'Paige Thompson' -- CI120 */
	(2049, 7083210, 8034971), /* 229: 'Jesse Chiu' and 'Paige Thompson' -- CI311 */
	(2050, 7083210, 8034971); /* 230: 'Jesse Chiu' and 'Paige Thompson' -- CI490 */

/* starting digit of 1 indicates an appointmentID */
/* starting digit of 2 indicates a classID */
/* starting digit of 7 indicates a employeeID */
/* starting digit of 8 indicates a tutorID */
/* starting digit of 9 indicates a studentID */
/* sectionIDs and sessionIDs are auto_incremented */