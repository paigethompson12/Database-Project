/* Appointments Table */
/* By Christina Corliss and Paige Thompson */
	
DROP TABLE IF EXISTS appointments;
	
CREATE TABLE IF NOT EXISTS appointments(
	appointmentID INT NOT NULL,
	tutorID INT NOT NULL,
	studentID INT NOT NULL,
	sectionID INT NOT NULL,
	appointment_time DATETIME,
	building VARCHAR(15),
	room VARCHAR(10),
	PRIMARY KEY(appointmentID));

/* Will be more uncommon (higher level) courses because those courses do not have pre-scheduled sessions */
INSERT INTO appointments
	(appointmentID, tutorID, studentID, sectionID, appointment_time, building, room) VALUES
	/* Comment information: tutor_name and student_name */
	(1001, 8034971, 9001234, 2, '2021-09-23 14:00:00', 'Building 1', 'Room 101'), /* 'Paige Thompson' and 'Connor Algeri' */
	(1002, 8005679, 9001122, 7, '2021-09-23 14:00:00', 'Building 2', 'Room 203'), /* 'Cordaellia Farrell' and 'Jack Bauer' */
	(1003, 8006782, 9000074, 9, '2021-09-23 14:00:00', 'Building 3', 'Room 123'), /* 'Brandon Todd' and 'Zackary Lally' */
	(1004, 8003454, 9100238, 22, '2021-09-23 14:00:00', 'Building 4', 'Room 115'), /* 'Christina Corliss' and 'Ryan Beegle' */
	(1005, 8000345, 9001122, 25, '2021-09-24 14:00:00', 'Building 1', 'Room 101'), /* 'Alex Santalov' and 'Jack Bauer' */
	(1006, 8046346, 9144800, 30, '2021-09-24 14:00:00', 'Building 2', 'Room 203'), /* 'Thomas Dewald' and 'Nathan Ha' */
	(1007, 8045647, 9004382, 14, '2021-09-24 14:00:00', 'Building 3', 'Room 123'), /* 'Gabriael Moore' and 'Patrick Coulon' */
	(1008, 8054758, 9144800, 117, '2021-09-24 14:00:00', 'Building 4', 'Room 115'), /* 'Amanda Goodbody' and 'Nathan Ha' */
	(1009, 8002347, 9010101, 62, '2021-09-25 14:00:00', 'Building 1', 'Room 101'), /* 'Angel Appelzoller' and 'James Frost' */
	(1010, 8056760, 9112294, 41, '2021-09-25 14:00:00', 'Building 2', 'Room 203'), /* 'Brian Zelt' and 'Tomas Schweitzer' */
	(1011, 8023511, 9002255, 134, '2021-09-25 14:00:00', 'Building 3', 'Room 123'), /* 'Tyler Stiff' and 'Jacob Sander' */
	(1012, 8056760, 9058788, 47, '2021-09-25 14:00:00', 'Building 4', 'Room 115'), /* 'Brian Zelt' and 'Eva Hansen' */
	(1013, 8000345, 9009709, 4, '2021-09-26 14:00:00', 'Building 1', 'Room 101'), /* 'Alex Santalov' and 'Dominik Martinez' */
	(1014, 8056749, 9098005, 77, '2021-09-26 14:00:00', 'Building 2', 'Room 203'), /* 'Nathan Kruger' and 'Kyle LaClair' */
	(1015, 8002385, 9001436, 68, '2021-09-26 14:00:00', 'Building 3', 'Room 123'), /* 'Nathan Burk' and 'Gabriel Rodriguez' */
	(1016, 8000016, 9010101, 19, '2021-09-26 14:00:00', 'Building 4', 'Room 115'), /* 'Ryan Begley' and 'James Frost' */
	(1017, 8002347, 9111827, 71, '2021-09-27 14:00:00', 'Building 1', 'Room 101'), /* 'Angel Appelzoller' and 'Jacob Hart' */
	(1018, 8002347, 9098005, 70, '2021-09-27 14:00:00', 'Building 2', 'Room 203'), /* 'Angel Appelzoller' and 'Kyle LaClair' */
	(1019, 8056749, 9001122, 97, '2021-09-27 14:00:00', 'Building 3', 'Room 123'), /* 'Nathan Kruger' and 'Jack Bauer' */
	(1020, 8034660, 9100238, 99, '2021-09-27 14:00:00', 'Building 4', 'Room 115'), /* 'Katie Sugiyama' and 'Ryan Beegle' */
	(1021, 8076441, 9058788, 100, '2021-09-28 14:00:00', 'Building 1', 'Room 101'), /* 'Carson Yinger' and 'Eva Hansen' */
	(1022, 8007844, 9001234, 87, '2021-09-28 14:00:00', 'Building 2', 'Room 203'), /* 'Sarah Chinn' and 'Connor Algeri' */
	(1023, 8002347, 9001436, 70, '2021-09-28 14:00:00', 'Building 3', 'Room 123'), /* 'Angel Appelzoller' and 'Gabriel Rodriguez' */
	(1024, 8045814, 9009709, 56, '2021-09-28 14:00:00', 'Building 4', 'Room 115'), /* 'Benjamin Sheldon' and 'Dominik Martinez' */
	(1025, 8008465, 9111827, 95, '2021-09-29 14:00:00', 'Building 1', 'Room 101'), /* 'Hunter Nudson' and 'Jacob Hart' */
	(1026, 8149204, 9000074, 102, '2021-09-29 14:00:00', 'Building 2', 'Room 203'), /*  'Courtney Nelson' and 'Zackary Lally' */
	(1027, 8095493, 9112294, 106, '2021-09-29 14:00:00', 'Building 3', 'Room 123'), /* 'Joshua Parmenter' and 'Tomas Schweitzer' */
	(1028, 8009543, 9002255, 110, '2021-09-29 14:00:00', 'Building 4', 'Room 115'); /* 'Alexa Dunaisky' and 'Jacob Sander' */
	
/* starting digit of 1 indicates an appointmentID */
/* starting digit of 2 indicates a classID */
/* starting digit of 7 indicates a employeeID */
/* starting digit of 8 indicates a tutorID */
/* starting digit of 9 indicates a studentID */
/* sectionIDs and sessionIDs are auto_incremented */