/* Tutors Table */
/* By Cordaellia Farrell and Christina Corliss */

DROP TABLE IF EXISTS tutors;
	
CREATE TABLE IF NOT EXISTS tutors (
	tutorID INT NOT NULL,
	name VARCHAR(35),
	email VARCHAR(20),
	gradYear INT,
	PRIMARY KEY(tutorID));

/* 45 tutors total */
INSERT INTO tutors
	(tutorID, name, email, gradYear) VALUES
	(8034971, 'Paige Thompson', 'thompp13@my.erau.edu', 2023),
	(8005679, 'Cordaellia Farrell', 'farrelc2@my.erau.edu', 2023 ),
	(8006782, 'Brandon Todd', 'toddb3@my.erau.edu', 2023 ),
	(8003454, 'Christina Corliss', 'corlissc@my.erau.edu', 2023 ),
	(8000345, 'Alex Santalov', 'santaloa@my.erau.edu', 2022),
	(8046346, 'Thomas Dewald', 'dewaldt@my.erau.edu', 2022),
	(8045647, 'Gabriael Moore', 'mooreg15@my.erau.edu', 2024),
	(8054758, 'Amanda Goodbody', 'goodboda@my.erau.edu', 2024),
	(8000009, 'Jordan Owens', 'owensj31@my.erau.edu', 2024),
	(8056760, 'Brian Zelt', 'zeltb@my.erau.edu', 2023),
	(8023511, 'Tyler Stiff', 'stifft@my.erau.edu', 2022),
	(8056761, 'Hayden Roszell', 'roszellh@my.erau.edu', 2023),
	(8000346, 'Jake Whitaker', 'whitakj9@my.erau.edu', 2023),
	(8045814, 'Benjamin Sheldon', 'sheldob2@my.erau.edu', 2023),
	(8002385, 'Nathan Burk', 'burkn@my.erau.edu', 2023),
	(8000016, 'Ryan Begley', 'begleyr@my.erau.edu', 2023),
	(8002347, 'Angel Appelzoller', 'appelzoa@my.erau.edu', 2024),
	(8002348, 'Issac Juan', 'juani@my.erau.edu', 2025),
	(8056749, 'Nathan Kruger', 'krugern@my.erau.edu', 2025),
	(8034660, 'Katie Sugiyama', 'sugiyamk@my.erau.edu', 2025),
	(8076441, 'Carson Yinger', 'yingerc@my.erau.edu', 2025),
	(8007844, 'Sarah Chinn', 'chinns@my.erau.edu', 2025),
	(8002349, 'Caleb Loomis', 'loomisc2@my.erau.edu', 2024),
	(8008465, 'Hunter Nudson', 'nudsonh@my.erau.edu', 2024),
	(8149204, 'Courtney Nelson', 'nelsoc32@my.erau.edu', 2022),
	(8095493, 'Joshua Parmenter', 'parmentj@my.erau.edu', 2022),
	(8009543, 'Alexa Dunaisky', 'dunaiska@my.erau.edu', 2022),
	(8002355, 'Jacob Hindmarsh', 'hindmarj@my.erau.edu', 2023),
	(8030249, 'Clarissa Winks', 'winksc@my.erau.edu', 2023),
	(8094569, 'Sarah Reiter', 'reiters1@my.erau.edu', 2023),
	(8043092, 'Hamad Aloud', 'aloudh@my.erau.edu', 2023),
	(8092341, 'Kevin Anderson', 'anderk52@my.erau.edu', 2023),
	(8014934, 'Ruth Avila', 'avilar6@my.erau.edu', 2023),
	(8013495, 'Eric Babcock', 'babcoce1@my.erau.edu', 2022),
	(8034929, 'Andrew Blankenship', 'blankea3@my.erau.edu', 2024),
	(8091080, 'Georgiy Bondar', 'bondarg@my.erau.edu', 2023),
	(8003461, 'Bradyn Braithwaite', 'braithb1@my.erau.edu', 2024), 
	(8014901, 'Michael Butler', 'butlem11@my.erau.edu', 2022),
	(8030510, 'Ashleigh Cook', 'cooka14@my.erau.edu', 2022),
	(8023490, 'Cortes Crawford', 'crawfc21@my.erau.edu', 2023),
	(8013840, 'Chase Davis', 'johnsk90@my.erau.edu', 2023),
	(8013481, 'Spencer Davis', 'daviss76@my.erau.edu', 2024),
	(8094987, 'Kate Delany', 'delaneyk@my.erau.edu', 2023),
	(8058210, 'Andrew Erickson', 'ericksa6@my.erau.edu', 2023),
	(8342841, 'Alexandra Ralph', 'ralpha2@my.erau.edu', 2023);
	
/* starting digit of 1 indicates an appointmentID */
/* starting digit of 2 indicates a classID */
/* starting digit of 7 indicates a employeeID */
/* starting digit of 8 indicates a tutorID */
/* starting digit of 9 indicates a studentID */
/* sectionIDs and sessionIDs are auto_incremented */