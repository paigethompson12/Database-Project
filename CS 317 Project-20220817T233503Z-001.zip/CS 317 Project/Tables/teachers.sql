/* Teachers Table */
/* By Cordaellia Farrell and Christina Corliss */

DROP TABLE IF EXISTS teachers;
	
CREATE TABLE IF NOT EXISTS teachers (
	employeeID INT NOT NULL,
	name VARCHAR(40),
	email VARCHAR(25),
	PRIMARY KEY(employeeID));

/* 65 total teachers */
INSERT INTO teachers
	(employeeID, name, email) VALUES
	(7034971, 'Michael Van Hilst','vanhilism@erau.edu' ),
	(7005679, 'Luis Zapata Rivera','zapatarl@erau.edu'),
	(7006782, 'Matthew Jaffe','jaffem@erau.edu'),
	(7003454, 'Heather Marriott','marric72@erau.edu'),
	(7000345, 'Christopher Briggs','briggsc1@erau.edu'),
	(7046346, 'Leeann Chen','chenl@erau.edu'),
	(7045647, 'Sameer Abufardeh','abufards@erau.edu'),
	(7054758, 'Hisaya Tstsui','tsuts157@erau.edu'),
	(7002347, 'Joel Schipper','schippej@erau.edu'),
	(7056760, 'Jules Yimga','yimgaj@erau.edu'),
	(7023511, 'Kelly Lambert','lamberk1@erau.edu'),
	(7056761, 'Michele Zanolin','zanolimn@erau.edu'),
	(7000014, 'Preston Jones','jonesp13@erau.edu'),
	(7002385, 'Scott Post','posts1@erau.edu'),
	(7002342, 'Lara Ismert', 'ismertl@erau.edu'),
	(7000016, 'Shigeo Hayashibara','hayasd87@erau.edu'),
	(7002323, 'John Matthew Pavlina', 'pavlinaj@erau.edu'),
	(7002131, 'Elliott Bryner', 'brynere@erau.edu'),
	(7002191, 'John Edward Post, Jr.', 'postj@erau.edu'),
	(7012311, 'Brenda Haven', 'havenb@erau.edu'),
	(7091381, 'Scott Post', 'posts1@erau.edu'),
	(7001223, 'Ken Anothony Bordignon', 'bordignk@erau.edu'),
	(7001088, 'Josef Penaovski', 'panovskij@erau.edu'),
	(7008128, 'Muna Slewa', 'slewam@erau.edu'),
	(7013084, 'Radek Glaser', 'glaserr@erau.edu'),
	(7098879, 'Wantanabe Tatsunari', 'wantanabt@erau.edu'),
	(7091283, 'Susan Rauch', 'rauchs1@erau.edu'),
	(7093284, 'Padraig Houlahan', 'houlahap@erau.edu'),
	(7002141, 'Elizabeth Gretarsson', 'jesse400@erau.edu'),
	(7093529, 'Dennis Kodimer', 'kodimerd@erau.edu'),
	(7032894, 'Michael McClure', 'mcclurm3@erau.edu'),
	(7019412, 'Joshua Sullins', 'sullinsj@erau.edu'),
	(7023841, 'Mary Beck', 'beckae0@erau.edu'),
	(7012318, 'Eric Kumpf', 'kumpfe@erau.edu'),
	(7012431, 'Ahmed Sulyman', 'sulymana@erau.edu'), 
	(7023483, 'Robert Olive', 'oliver1@erau.edu'),
	(7032942, 'John Sevic', 'sevicj@erau.edu'),
	(7048258, 'Seth McNeill', 'mcneils2@erau.edu'),
	(7034858, 'Timothy Callahan', 'callahat@erau.edu'),
	(7032841, 'Paul Bunnell', 'bunnellp@erau.edu'),
	(7034893, 'William MacKunis', 'macjuniw@erau.edu'),
	(7082609, 'Tomomi Otani', 'otanit@erau.edu'),
	(7034853, 'Katharine Moran', 'morank5@erau.edu'),
	(7084596, 'Bryan Armentrout', 'armentb1@erau.edu'),
	(7095832, 'Byonghoon Seo', 'seob1@erau.edu'),
	(7069403, 'Dan Maronde', 'maronded@erau.edu'),
	(7093243, 'Brian Rachford', 'rachf7ac@erau.edu'),
	(7079742, 'Quentin Bailey', 'baileyq@erau.edu'),	
	(7083405, 'Brent Spencer', 'spenceb3@erau.edu'),
	(7093467, 'Michelle Elghardgui', 'elghardm@erau.edu'),	
	(7098353, 'Cameron Williams', 'willc187@erau.edu'),
	(7094480, 'Jeri Hamilton', 'hamilj32@erau.edu'),
	(7034501, 'Jian Cheng', 'chengj5@erau.edu'),
	(7039883, 'Angelynn Alvarez', 'alvara44@erau.edu'),
	(7003235, 'Keke Wang', 'wangk5@erau.edu'),
	(7023408, 'Dean Holbrook', 'holbrod1@erau.edu'),
	(7029026, 'Edward Poon', 'poon3de@erau.edu'),
	(7090319, 'Hisaya Tsutsui', 'tsuts157@erau.edu'),
	(7082343, 'Brent Solie', 'solieb@erau.edu'),
	(7003491, 'Hadi Ali', 'alih9@erau.edu'),
	(7023911, 'Joseph Smith', 'smitj402@erau.edu'),
	(7012399, 'John Sevic', 'sevicj@erau.edu'),
	(7029321, 'Shigeo Hayashibara', 'hayasd87@my.erau.edu'),
	(7012347, 'Atanu Halder', 'haldera@erau.edu'),
	(7083210, 'Jesse Chiu', 'chiuj2@erau.edu');

/* starting digit of 1 indicates an appointmentID */
/* starting digit of 2 indicates a classID */
/* starting digit of 7 indicates a employeeID */
/* starting digit of 8 indicates a tutorID */
/* starting digit of 9 indicates a studentID */
/* sectionIDs and sessionIDs are auto_incremented */
