/* Students Table */
/* By Paige Thompson */

DROP TABLE IF EXISTS students;
	
CREATE TABLE IF NOT EXISTS students (
	studentID INT NOT NULL,
	name VARCHAR(35),
	email VARCHAR(20),
	gradYear INT,
	PRIMARY KEY(studentID));

/* 30 students total */
INSERT INTO students
	(studentID, name, email, gradYear) VALUES
	(9001234, 'Connor Algeri', 'algeric@my.erau.edu', 2024),
	(9013577, 'Anivartin Anand', 'ananda@my.erau.edu', 2020),
	(9001122, 'Jack Bauer', 'bauerj12@my.erau.edu', 2020),
	(9000074, 'Zackary Lally', 'bauerz3@my.erau.edu', 2024 ),
	(9100238, 'Ryan Beegle', 'beegler@my.erau.edu', 2022),
	(9004382, 'Patrick Coulon', 'coulonp1@my.erau.edu', 2025),
	(9006748, 'Kobie Deleonard', 'deleonak@my.erau.edu', 2024),
	(9010101, 'James Frost', 'frostj9@my.erau.edu', 2024),
	(9000346, 'Zachary Garcia', 'garciaz1@my.erau.edu', 2024),
	(9002022, 'Joseph Guerrera', 'guerrej8@my.erau.edu', 2024),
	(9144800, 'Nathan Ha', 'han@my.erau.edu', 2022),
	(9111827, 'Jacob Hart', 'hartj32@my.erau.edu', 2024),
	(9001836, 'Karim Hernandez', 'hernak20@my.erau.edu', 2024),
	(9010204, 'Gabrielle Johnson', 'johsg50@my.erau.edu', 2024),
	(9000006, 'Jimmall Kincaid', 'kincaij6@my.erau.edu', 2024),
	(9002877, 'Ethan Kriel', 'kriele@my.erau.edu', 2024),
	(9098005, 'Kyle LaClair', 'laclairk@my.erau.edu', 2024),
	(9007858, 'Aidan Maney', 'maneya@my.erau.edu', 2025),
	(9009709, 'Dominik Martinez', 'martd127@my.erau.edu', 2025),
	(9000307, 'Gonzolo Palomares', 'palomarg@my.erau.edu', 2025),
	(9005432, 'Hannah Pehl', 'pehlh@my.erau.edu', 2025),
	(9003049, 'Matthew Pierce', 'piercm12@my.erau.edu', 2025),
	(9030292, 'Mckenna Rendig', 'rendigm@my.erau.edu', 2020),
	(9112294, 'Tomas Schweitzer', 'schweitt@my.erau.edu', 2024),
	(9002065, 'Alexander Simmons', 'simmoa14@my.erau.edu', 2025),
	(9002255, 'Jacob Sander', 'sandej39@my.erau.edu', 2025),
	(9001436, 'Gabriel Rodriguez', 'rodrig45@my.erau.edu', 2025),
	(9058788, 'Eva Hansen', 'hanse82@my.erau.edu', 2024),
	(9038295, 'Kate Shriki', 'shrikik@.my.erau.edu', 2022),
	(9034902, 'Janessa Slone', 'slonej1@my.erau.edu', 2023);

/* starting digit of 1 indicates an appointmentID */
/* starting digit of 2 indicates a classID */
/* starting digit of 7 indicates a employeeID */
/* starting digit of 8 indicates a tutorID */
/* starting digit of 9 indicates a studentID */
/* sectionIDs and sessionIDs are auto_incremented */