/* Subjects Table */
/* By Paige Thompson and Christina Corliss */

DROP TABLE IF EXISTS subjects;
	
CREATE TABLE IF NOT EXISTS subjects (
	classID INT NOT NULL, 
	courseNum VARCHAR(8),
	name VARCHAR(55),
	credits INT NOT NULL,
	PRIMARY KEY(classID));

/* 50 subjects total */
INSERT INTO subjects
	(classID, courseNum, name, credits) VALUES
	(2001, 'AE302', 'Aerodynamics II', 3),
	(2002, 'AE318', 'Aerospace Structures I', 3),
	(2003, 'AE430', 'Control System Analysis and Design', 3),
	(2004, 'CS317', 'Files and Database Systems', 3),
	(2005, 'CEC320', 'Microprocessors', 3),
	(2006, 'CEC220', 'Digital Circuits', 3),
	(2007, 'CEC223', 'Digital Circuits Laboratory', 1),
	(2008, 'CS420', 'Operating Systems', 3),
	(2009, 'CE460', 'Telecommunications Systems', 3),
	(2010, 'CE470', 'Computer Architecture', 3),
	(2011, 'CS315', 'Data Structures and Algorithms', 3),
	(2012, 'CS118', 'Fundamentals of Computer Programming', 3),
	(2013, 'CS125', 'Computer Science I', 3),
	(2014, 'CS225', 'Computer Science II', 4),
	(2015, 'CS225L', 'Computer Science II Laboratory', 0),
	(2016, 'CS332', 'Organization of Programming Languages', 3),
	(2017, 'CS432', 'Information and Computer Security', 3),
	(2018, 'SE300', 'Software Engineering Practices', 3),
	(2019, 'ES201', 'Statics', 3),
	(2020, 'ES202', 'Solid Mechanics', 3),
	(2021, 'ES204', 'Dynamics', 3),
	(2022, 'ES205', 'Thermodynamics', 3),
	(2023, 'ES206', 'Fluid Mechanics', 3),
	(2024, 'SE310', 'Analysis and Design of Software Systems', 3),
	(2025, 'SE420', 'Software Quality Assurance', 3),
	(2026, 'MA412', 'Probability and Statistics', 3),
	(2027, 'EE335', 'Electrical Engineering I', 2),
	(2028, 'EE336', 'Electrical Engineering I Laboratory', 1),
	(2029, 'EC225', 'Engineering Economics', 3),
	(2030, 'HU330', 'Values and Ethics', 3),
	(2031, 'PS250', 'Physics III',3),
	(2032, 'SE320', 'Software Construction', 3),
	(2033, 'EGR101', 'Intro to Engineering', 3),
	(2034, 'COM221', 'Technical Report Writing', 3),
	(2035, 'UNIV101', 'College Success', 1),
	(2036, 'MA225', 'Discrete Structures', 3),
	(2037, 'ME309', 'Airbreathing & Rocket Propulsion', 3),
	(2038, 'PS150', 'Physics I for Engineers', 3),
	(2039, 'PS160', 'Physics II for Engineers', 3),
	(2040, 'MA241', 'Calculus and Analytical Geometry I', 4),
	(2041, 'MA242', 'Calculus and Analytical Geometry II', 4),
	(2042, 'MA243', 'Calculus and Analytical Geometry III', 4),
	(2043, 'MA345', 'Differential Equations and Matrix Methods', 4),
	(2044, 'EGR115', 'Introduction to Computing for Engineers', 3),
	(2045, 'EGR200', 'Computer Aided Conceptual Design of Aerospace Systems', 3),
	(2046, 'CS213', 'Introduction to Computer Networks', 3),
	(2047, 'CI119', 'Introduction to Cybersecurity for Non-Majors', 3),
	(2048, 'CI120', 'Introduction to Cybersecurity for Majors', 3),
	(2049, 'CI311', 'Securing Computer Networks', 3),
	(2050, 'CI490', 'Cyber Capstone Project', 3);
	
/* starting digit of 1 indicates an appointmentID */
/* starting digit of 2 indicates a classID */
/* starting digit of 7 indicates a employeeID */
/* starting digit of 8 indicates a tutorID */
/* starting digit of 9 indicates a studentID */
/* sectionIDs and sessionIDs are auto_incremented */