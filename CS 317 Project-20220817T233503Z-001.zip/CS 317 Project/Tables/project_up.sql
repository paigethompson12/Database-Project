/* Tutors Table */
/* By Paige Thompson */
	
CREATE TABLE IF NOT EXISTS appointments(
	appointmentID INT NOT NULL,
	tutorID INT NOT NULL,
	studentID INT NOT NULL,
	sectionID INT NOT NULL,
	appointment_time DATETIME,
	building VARCHAR(15),
	room VARCHAR(10),
	PRIMARY KEY(appointmentID));

/* Will be more uncommon (higher level) courses because those courses do not have pre-scheduled sessions */
INSERT INTO appointments
	(appointmentID, tutorID, studentID, sectionID, appointment_time, building, room) VALUES
	/* Comment information: tutor_name and student_name */
	(1001, 8034971, 9001234, 2, '2021-09-23 14:00:00', 'Building 1', 'Room 101'), /* 'Paige Thompson' and 'Connor Algeri' */
	(1002, 8005679, 9001122, 7, '2021-09-23 14:00:00', 'Building 2', 'Room 203'), /* 'Cordaellia Farrell' and 'Jack Bauer' */
	(1003, 8006782, 9000074, 9, '2021-09-23 14:00:00', 'Building 3', 'Room 123'), /* 'Brandon Todd' and 'Zackary Lally' */
	(1004, 8003454, 9100238, 22, '2021-09-23 14:00:00', 'Building 4', 'Room 115'), /* 'Christina Corliss' and 'Ryan Beegle' */
	(1005, 8000345, 9001122, 25, '2021-09-24 14:00:00', 'Building 1', 'Room 101'), /* 'Alex Santalov' and 'Jack Bauer' */
	(1006, 8046346, 9144800, 30, '2021-09-24 14:00:00', 'Building 2', 'Room 203'), /* 'Thomas Dewald' and 'Nathan Ha' */
	(1007, 8045647, 9004382, 14, '2021-09-24 14:00:00', 'Building 3', 'Room 123'), /* 'Gabriael Moore' and 'Patrick Coulon' */
	(1008, 8054758, 9144800, 117, '2021-09-24 14:00:00', 'Building 4', 'Room 115'), /* 'Amanda Goodbody' and 'Nathan Ha' */
	(1009, 8002347, 9010101, 62, '2021-09-25 14:00:00', 'Building 1', 'Room 101'), /* 'Angel Appelzoller' and 'James Frost' */
	(1010, 8056760, 9112294, 41, '2021-09-25 14:00:00', 'Building 2', 'Room 203'), /* 'Brian Zelt' and 'Tomas Schweitzer' */
	(1011, 8023511, 9002255, 134, '2021-09-25 14:00:00', 'Building 3', 'Room 123'), /* 'Tyler Stiff' and 'Jacob Sander' */
	(1012, 8056760, 9058788, 47, '2021-09-25 14:00:00', 'Building 4', 'Room 115'), /* 'Brian Zelt' and 'Eva Hansen' */
	(1013, 8000345, 9009709, 4, '2021-09-26 14:00:00', 'Building 1', 'Room 101'), /* 'Alex Santalov' and 'Dominik Martinez' */
	(1014, 8056749, 9098005, 77, '2021-09-26 14:00:00', 'Building 2', 'Room 203'), /* 'Nathan Kruger' and 'Kyle LaClair' */
	(1015, 8002385, 9001436, 68, '2021-09-26 14:00:00', 'Building 3', 'Room 123'), /* 'Nathan Burk' and 'Gabriel Rodriguez' */
	(1016, 8000016, 9010101, 19, '2021-09-26 14:00:00', 'Building 4', 'Room 115'), /* 'Ryan Begley' and 'James Frost' */
	(1017, 8002347, 9111827, 71, '2021-09-27 14:00:00', 'Building 1', 'Room 101'), /* 'Angel Appelzoller' and 'Jacob Hart' */
	(1018, 8002347, 9098005, 70, '2021-09-27 14:00:00', 'Building 2', 'Room 203'), /* 'Angel Appelzoller' and 'Kyle LaClair' */
	(1019, 8056749, 9001122, 97, '2021-09-27 14:00:00', 'Building 3', 'Room 123'), /* 'Nathan Kruger' and 'Jack Bauer' */
	(1020, 8034660, 9100238, 99, '2021-09-27 14:00:00', 'Building 4', 'Room 115'), /* 'Katie Sugiyama' and 'Ryan Beegle' */
	(1021, 8076441, 9058788, 100, '2021-09-28 14:00:00', 'Building 1', 'Room 101'), /* 'Carson Yinger' and 'Eva Hansen' */
	(1022, 8007844, 9001234, 87, '2021-09-28 14:00:00', 'Building 2', 'Room 203'), /* 'Sarah Chinn' and 'Connor Algeri' */
	(1023, 8002347, 9001436, 70, '2021-09-28 14:00:00', 'Building 3', 'Room 123'), /* 'Angel Appelzoller' and 'Gabriel Rodriguez' */
	(1024, 8045814, 9009709, 56, '2021-09-28 14:00:00', 'Building 4', 'Room 115'), /* 'Benjamin Sheldon' and 'Dominik Martinez' */
	(1025, 8008465, 9111827, 95, '2021-09-29 14:00:00', 'Building 1', 'Room 101'), /* 'Hunter Nudson' and 'Jacob Hart' */
	(1026, 8149204, 9000074, 102, '2021-09-29 14:00:00', 'Building 2', 'Room 203'), /*  'Courtney Nelson' and 'Zackary Lally' */
	(1027, 8095493, 9112294, 106, '2021-09-29 14:00:00', 'Building 3', 'Room 123'), /* 'Joshua Parmenter' and 'Tomas Schweitzer' */
	(1028, 8009543, 9002255, 110, '2021-09-29 14:00:00', 'Building 4', 'Room 115'); /* 'Alexa Dunaisky' and 'Jacob Sander' */
	
CREATE TABLE IF NOT EXISTS instructors_by_subject (
	sectionID INT NOT NULL AUTO_INCREMENT,
	classID INT NOT NULL,
	employeeID INT NOT NULL,
	tutorID INT NOT NULL,
	PRIMARY KEY(sectionID)); 

/* 230 sections total */
INSERT INTO instructors_by_subject
	(classID, employeeID, tutorID) VALUES
	/* comment information order is: sectionID, teacher_name, tutor_name, and course_num */
	(2001, 7091381, 8342841), /* 1: 'Scott Post' and 'Alexandra Ralph' -- AE301 */ 
	(2002, 7013084, 8342841), /* 2: 'Radek Glaser' and 'Alexandra Ralph' -- AE318 */
	(2003, 7001223, 8046346), /* 3: 'Ken Anothony Bordingnon' and 'Thomas Dewald' -- AE430 */
	(2004, 7034971, 8000345), /* 4: 'Michael Van Hilst' and 'Alex Santalov' -- CS317 */
	(2005, 7005679, 8000346), /* 5: 'Luis Zapata Rivera' and 'Jake Whitaker' -- CEC320 */
	(2006, 7002347, 8023511), /* 6: 'Joel Schipper' and 'Tyler Stiff' -- CEC220 */
	(2006, 7093529, 8005679), /* 7: 'Dennis Kodimer' and 'Cordaellia Farrell' -- CEC220 */
	(2006, 7093529, 8005679), /* 8: 'Dennis Kodimer' and 'Cordaellia Farrell' -- CEC220 */
	(2006, 7002323, 8006782), /* 9: 'John Matthew Pavlina' and 'Brandon Todd' -- CEC220 */
	(2007, 7002323, 8006782), /* 10: 'John Matthew Pavlina' and 'Brandon Todd' -- CEC223 */
	(2007, 7002323, 8006782), /* 11: 'John Matthew Pavlina' and 'Brandon Todd' -- CEC223 */
	(2007, 7093529, 8005679), /* 12: 'Dennis Kodimer' and 'Cordaellia Farrell' -- CEC223 */
	(2007, 7093529, 8005679), /* 13: 'Dennis Kodimer' and 'Cordaellia Farrell' -- CEC223 */
	(2008, 7006782, 8045647), /* 14: 'Matthew Jaffe' and 'Gabriael Moore' -- CS420 */
	(2009, 7034971, 8002348), /* 15: 'Michael Van Hilst' and 'Issac Juan' -- CE 460 */
	(2010, 7005679, 8056749), /* 16: 'Luis Zapata Rivera' and 'Nathan Kruger' -- CE 470 */
	(2010, 7006782, 8045647), /* 17: 'Matthew Jaffe' and 'Gabriael Moore' -- CE 470 */
	(2011, 7006782, 8000016), /* 18: 'Matthew Jaffe' and 'Ryan Begley' -- CS315 */	
	(2011, 7006782, 8000016), /* 19: 'Matthew Jaffe' and 'Ryan Begley' -- CS315 */
	(2012, 7003454, 8076441), /* 20: 'Heather Marriott' and 'Carson Yinger' -- CS118 */
	(2012, 7003454, 8076441), /* 21: 'Heather Marriott' and 'Carson Yinger' -- CS118 */
	(2013, 7003454, 8003454), /* 22: 'Heather Marriott' and 'Christina Corliss' -- CS125 */
	(2013, 7003454, 8003454), /* 23: 'Heather Marriott' and 'Christina Corliss'-- CS125 */	
	(2014, 7003454, 8003454), /* 24: 'Heather Marriott' and 'Christina Corliss'-- CS225 */
	(2014, 7034971, 8000345), /* 25: 'Michael Van Hilst' and 'Alex Santalov' -- CS225 */
	(2015, 7003454, 8003454), /* 26: 'Heather Marriott' and 'Christina Corliss'-- CS225L */
	(2015, 7034971, 8000345), /* 27: 'Michael Van Hilst' and 'Alex Santalov' -- CS225L */	
	(2016, 7034971, 8000345), /* 28: 'Michael Van Hilst' and 'Alex Santalov' -- CS332 */	
	(2017, 7006782, 8000016), /* 29: 'Matthew Jaffe' and 'Ryan Begley' -- CS432 */	
	(2018, 7006782, 8000016), /* 30: 'Matthew Jaffe' and 'Ryan Begley'-- SE300 */
	(2018, 7006782, 8000016), /* 31: 'Matthew Jaffe' and 'Ryan Begley'-- SE300 */	
	(2019, 7008128, 8054758), /* 32: 'Muna Slewa' and 'Amanda Goodbody'-- ES201 */
	(2020, 7013084, 8054758), /* 33: 'Radek Glaser' and 'Amanda Goodbody'-- ES202 */
	(2021, 7001088, 8054758), /* 34: 'Josef Penaovski' and 'Amanda Goodbody'-- ES204 */
	(2022, 7012311, 8054758), /* 35: 'Brenda Haven' and 'Amanda Goodbody'-- ES205 */
	(2023, 7091381, 8054758), /* 36: 'Scott Post' and 'Amanda Goodbody'-- ES206 */	
	(2024, 7045647, 8000009), /* 37: 'Sameer Abufardeh' and 'Jordan Owens' -- SE310 */
	(2025, 7045647, 8000009), /* 38: 'Sameer Abufardeh' and 'Jordan Owens'-- SE420 */
	(2026, 7098879, 8000009), /* 39: 'Wantanabe Tatsunari' and 'Jordan Owens' -- MA412 */
	(2026, 7098879, 8000009), /* 40: 'Wantanabe Tatsunari' and 'Jordan Owens' -- MA412 */	
	(2027, 7002323, 8056760), /* 41: 'John Matthew Pavlina' and 'Brian Zelt' -- EE335 */
	(2027, 7002323, 8056760), /* 42: 'John Matthew Pavlina' and 'Brian Zelt' -- EE335 */
	(2027, 7002347, 8056761), /* 43: 'Joel Schipper' and 'Hayden Roszell' -- EE335 */
	(2027, 7002347, 8056761), /* 44: 'Joel Schipper' and 'Hayden Roszell' -- EE335 */
	(2027, 7012431, 8000346), /* 45: 'Ahmed Sulyman' and 'Jake Whitaker' -- EE335 */
	(2027, 7012431, 8000346), /* 46: 'Ahmed Sulyman' and 'Jake Whitaker' -- EE335 */	
	(2028, 7002191, 8056760), /* 47: 'John Edward Post, Jr.' and 'Brian Zelt'-- EE336 */
	(2028, 7002191, 8056760), /* 48: 'John Edward Post, Jr.' and 'Brian Zelt'-- EE336 */
	(2028, 7023483, 8056761), /* 49: 'Robert Olive' and 'Hayden Roszell' -- EE336 */
	(2028, 7023483, 8056761), /* 50: 'Robert Olive' and 'Hayden Roszell' -- EE336 */
	(2028, 7023483, 8056761), /* 51: 'Robert Olive' and 'Hayden Roszell' -- EE336 */
	(2028, 7023483, 8056761), /* 52: 'Robert Olive' and 'Hayden Roszell' -- EE336 */
	(2028, 7032942, 8000346), /* 53: 'John Sevic' and 'Jake Whitaker' -- EE336 */
	(2028, 7032942, 8000346), /* 54: 'John Sevic' and 'Jake Whitaker' -- EE336 */
	(2028, 7048258, 8045814), /* 55: 'Seth McNeill' and 'Benjamin Sheldon' -- EE336 */
	(2028, 7048258, 8045814), /* 56: 'Seth McNeill' and 'Benjamin Sheldon' -- EE336 */	
	(2029, 7056760, 8045814), /* 57: 'Jules Yimga' and 'Benjamin Sheldon' -- EC225 */
	(2029, 7056760, 8045814), /* 58: 'Jules Yimga' and 'Benjamin Sheldon' -- EC225 */	
	(2030, 7023511, 8002385), /* 59: 'Kelly Lambert' and 'Nathan Burk' -- HU330 */
	(2030, 7023511, 8002385), /* 60: 'Kelly Lambert' and 'Nathan Burk' -- HU330 */
	(2030, 7023511, 8002385), /* 61: 'Kelly Lambert' and 'Nathan Burk' -- HU330 */
	(2030, 7032894, 8002347), /* 62: 'Michael McClure' and 'Angel Appelzoller' -- HU330 */
	(2030, 7032894, 8002347), /* 63: 'Michael McClure' and 'Angel Appelzoller' -- HU330 */
	(2030, 7032894, 8002347), /* 64: 'Michael McClure' and 'Angel Appelzoller' -- HU330 */
	(2030, 7019412, 8002348), /* 65: 'Joshua Sullins' and 'Issac Juan' -- HU330 */
	(2030, 7019412, 8002348), /* 66: 'Joshua Sullins' and 'Issac Juan' -- HU330 */
	(2030, 7019412, 8002348), /* 67: 'Joshua Sullins' and 'Issac Juan' -- HU330 */
	(2031, 7056761, 8002385), /* 68: 'Michele Zanolin' and 'Nathan Burk' -- PS250 */
	(2031, 7056761, 8002385), /* 69: 'Michele Zanolin' and 'Nathan Burk' -- PS250 */
	(2031, 7034858, 8002347), /* 70: 'Timothy Callahan' and 'Angel Appelzoller' -- PS250 */
	(2031, 7034858, 8002347), /* 71: 'Timothy Callahan' and 'Angel Appelzoller' -- PS250 */	
	(2032, 7006782, 8000016), /* 72: 'Matthew Jaffe' and 'Ryan Begley' -- SE320 */
	(2033, 7002323, 8002348), /* 73: 'John Matthew Pavlina' and 'Issac Juan' -- EGR101 */
	(2033, 7002323, 8002348), /* 74: 'John Matthew Pavlina' and 'Issac Juan' -- EGR101 */	
	(2033, 7032841, 8056749), /* 75: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */
	(2033, 7032841, 8056749), /* 76: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */
	(2033, 7032841, 8056749), /* 77: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */
	(2033, 7032841, 8056749), /* 78: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */
	(2033, 7032841, 8056749), /* 79: 'Paul Bunnell' and 'Nathan Kruger' -- EGR101 */	
	(2034, 7091283, 8034660), /* 80: 'Susan Rauch' and 'Katie Sugiyama' -- COM221 */
	(2034, 7091283, 8034660), /* 81: 'Susan Rauch' and 'Katie Sugiyama' -- COM221 */
	(2034, 7091283, 8034660), /* 82: 'Susan Rauch' and 'Katie Sugiyama' -- COM221 */
	(2034, 7023841, 8076441), /* 83: 'Mary Beck' and 'Carson Yinger' -- COM221 */
	(2034, 7023841, 8076441), /* 84: 'Mary Beck' and 'Carson Yinger' -- COM221 */
	(2034, 7023841, 8076441), /* 85: 'Mary Beck' and 'Carson Yinger' -- COM221 */
	(2034, 7012318, 8007844), /* 86: 'Eric Kumpf' and 'Sarah Chinn' -- COM221 */
	(2034, 7012318, 8007844), /* 87: 'Eric Kumpf' and 'Sarah Chinn' -- COM221 */
	(2034, 7012318, 8007844), /* 88: 'Eric Kumpf' and 'Sarah Chinn' -- COM221 */	
	(2035, 7002191, 8002347), /* 89: 'John Edward Post, Jr.' and 'Angel Appelzoller' -- UNIV101 */
	(2035, 7083405, 8002349), /* 90: 'Brent Spencer' and 'Caleb Loomis' -- UNIV101 */
	(2035, 7083405, 8002349), /* 91: 'Brent Spencer' and 'Caleb Loomis' -- UNIV101 */
	(2035, 7083405, 8002349), /* 92: 'Brent Spencer' and 'Caleb Loomis' -- UNIV101 */
	(2035, 7083405, 8002349), /* 93: 'Brent Spencer' and 'Caleb Loomis' -- UNIV101 */
	(2035, 7093467, 8008465), /* 94: 'Michelle Elghardgui' and 'Hunter Nudson' -- UNIV101 */
	(2035, 7093467, 8008465), /* 95: 'Michelle Elghardgui' and 'Hunter Nudson' -- UNIV101 */
	(2035, 7093467, 8008465), /* 96: 'Michelle Elghardgui' and 'Hunter Nudson' -- UNIV101 */	
	(2036, 7002342, 8056749), /* 97: 'Lara Ismert' and 'Nathan Kruger' -- MA225 */
	(2036, 7002342, 8056749), /* 98: 'Lara Ismert' and 'Nathan Kruger' -- MA225 */
	(2037, 7002131, 8034660), /* 99: 'Elliott Bryner' and 'Katie Sugiyama' -- ME309 */	
	(2038, 7002141, 8076441), /* 100: 'Elizabeth Gretarsson' and 'Carson Yinger' -- PS150 */
	(2038, 7034893, 8149204), /* 101: 'William MacKunis' and 'Courtney Nelson' -- PS150 */
	(2038, 7034893, 8149204), /* 102: 'William MacKunis' and 'Courtney Nelson' -- PS150 */
	(2038, 7034893, 8149204), /* 103: 'William MacKunis' and 'Courtney Nelson' -- PS150 */
	(2038, 7082609, 8095493), /* 104: 'Tomomi Otani' and 'Joshua Parmenter' -- PS150 */
	(2038, 7082609, 8095493), /* 105: 'Tomomi Otani' and 'Joshua Parmenter' -- PS150 */
	(2038, 7082609, 8095493), /* 106: 'Tomomi Otani' and 'Joshua Parmenter' -- PS150 */
	(2038, 7082609, 8095493), /* 107: 'Tomomi Otani' and 'Joshua Parmenter' -- PS150 */
	(2038, 7034853, 8009543), /* 108: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7034853, 8009543), /* 109: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7034853, 8009543), /* 110: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7034853, 8009543), /* 111: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7034853, 8009543), /* 112: 'Katharine Moran' and 'Alexa Dunaisky' -- PS150 */
	(2038, 7084596, 8002355), /* 113: 'Bryan Armentrout' and 'Jacob Hindmarsh' -- PS150 */
	(2038, 7084596, 8002355), /* 114: 'Bryan Armentrout' and 'Jacob Hindmarsh' -- PS150 */
	(2038, 7084596, 8002355), /* 115: 'Bryan Armentrout' and 'Jacob Hindmarsh' -- PS150 */
	(2038, 7084596, 8002355), /* 116: 'Bryan Armentrout' and 'Jacob Hindmarsh' -- PS150 */	
	(2038, 7095832, 8054758), /* 117: 'Byonghoon Seo' and 'Amanda Goodbody'-- PS150 */
	(2038, 7095832, 8054758), /* 118: 'Byonghoon Seo' and 'Amanda Goodbody'-- PS150 */
	(2038, 7095832, 8054758), /* 119: 'Byonghoon Seo' and 'Amanda Goodbody'-- PS150 */
	(2038, 7095832, 8054758), /* 120: 'Byonghoon Seo' and 'Amanda Goodbody'-- PS150 */
	(2038, 7069403, 8000346), /* 121: 'Dan Maronde' and 'Jake Whitaker' -- PS150 */
	(2038, 7069403, 8000346), /* 122: 'Dan Maronde' and 'Jake Whitaker' -- PS150 */
	(2038, 7069403, 8000346), /* 123: 'Dan Maronde' and 'Jake Whitaker' -- PS150 */
	(2038, 7069403, 8000346), /* 124: 'Dan Maronde' and 'Jake Whitaker' -- PS150 */
	(2039, 7093284, 8046346), /* 125: 'Padraig Houlahan' and 'Thomas Dewald' -- PS160 */
	(2039, 7093284, 8046346), /* 126: 'Padraig Houlahan' and 'Thomas Dewald' -- PS160 */
	(2039, 7093284, 8046346), /* 127: 'Padraig Houlahan' and 'Thomas Dewald' -- PS160 */
	(2039, 7093284, 8046346), /* 128: 'Padraig Houlahan' and 'Thomas Dewald' -- PS160 */
	(2039, 7034858, 8034971), /* 129: 'Timothy Callahan' and 'Paige Thompson' -- PS160 */
	(2039, 7034858, 8034971), /* 130: 'Timothy Callahan' and 'Paige Thompson' -- PS160 */
	(2039, 7034858, 8034971), /* 131: 'Timothy Callahan' and 'Paige Thompson' -- PS160 */
	(2039, 7034858, 8034971), /* 132: 'Timothy Callahan' and 'Paige Thompson' -- PS160 */
	(2039, 7093243, 8023511), /* 133: 'Brian Rachford and 'Tyler Stiff' -- PS160 */
	(2039, 7093243, 8023511), /* 134: 'Brian Rachford and 'Tyler Stiff' -- PS160 */
	(2039, 7093243, 8023511), /* 135: 'Brian Rachford and 'Tyler Stiff' -- PS160 */
	(2039, 7093243, 8023511), /* 136: 'Brian Rachford and 'Tyler Stiff' -- PS160 */
	(2039, 7079742, 8000345), /* 137: 'Quentin Bailey' and 'Alex Santalov' -- PS160 */
	(2039, 7079742, 8000345), /* 138: 'Quentin Bailey' and 'Alex Santalov' -- PS160 */
	(2039, 7079742, 8000345), /* 139: 'Quentin Bailey' and 'Alex Santalov' -- PS160 */
	(2039, 7079742, 8000345), /* 140: 'Quentin Bailey' and 'Alex Santalov' -- PS160 */
	(2040, 7000345, 8003454), /* 141: 'Christopher Briggs' and 'Christina Corliss' -- MA241 */
	(2040, 7000345, 8003454), /* 142: 'Christopher Briggs' and 'Christina Corliss' -- MA241 */
	(2040, 7000345, 8003454), /* 143: 'Christopher Briggs' and 'Christina Corliss' -- MA241 */
	(2040, 7098353, 8005679), /* 144: 'Cameron Williams' and 'Cordaellia Farrell' -- MA241 */
	(2040, 7098353, 8005679), /* 145: 'Cameron Williams' and 'Cordaellia Farrell' -- MA241 */
	(2040, 7098353, 8005679), /* 146: 'Cameron Williams' and 'Cordaellia Farrell' -- MA241 */
	(2040, 7094480, 8007844), /* 147: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */	
	(2040, 7094480, 8007844), /* 148: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */	
	(2040, 7094480, 8007844), /* 149: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */
	(2040, 7094480, 8007844), /* 150: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */	
	(2040, 7094480, 8007844), /* 151: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */	
	(2040, 7094480, 8007844), /* 152: 'Jeri Hamilton' and 'Sarah Chinn' -- MA241 */
	(2041, 7034501, 8094569), /* 153: 'Jian Cheng' and 'Sarah Reiter' -- MA242 */
	(2041, 7034501, 8094569), /* 154: 'Jian Cheng' and 'Sarah Reiter' -- MA242 */	
	(2041, 7034501, 8094569), /* 155: 'Jian Cheng' and 'Sarah Reiter' -- MA242 */	
	(2041, 7034501, 8094569), /* 156: 'Jian Cheng' and 'Sarah Reiter' -- MA242 */		
	(2041, 7039883, 8043092), /* 157: 'Angelynn Alvarez' and 'Hamad Aloud' -- MA242 */
	(2041, 7039883, 8043092), /* 158: 'Angelynn Alvarez' and 'Hamad Aloud' -- MA242 */
	(2041, 7039883, 8043092), /* 159: 'Angelynn Alvarez' and 'Hamad Aloud' -- MA242 */
	(2041, 7039883, 8043092), /* 160: 'Angelynn Alvarez' and 'Hamad Aloud' -- MA242 */
	(2041, 7003235, 8092341), /* 161: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7003235, 8092341), /* 162: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7003235, 8092341), /* 163: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7003235, 8092341), /* 164: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7003235, 8092341), /* 165: 'Keke Wang' and 'Kevin Anderson' -- MA242 */	
	(2041, 7023408, 8014934), /* 166: 'Dean Holbrook' and 'Ruth Avila' -- MA242 */	
	(2041, 7023408, 8014934), /* 167: 'Dean Holbrook' and 'Ruth Avila' -- MA242 */
	(2041, 7023408, 8014934), /* 168: 'Dean Holbrook' and 'Ruth Avila' -- MA242 */
	(2041, 7023408, 8014934), /* 169: 'Dean Holbrook' and 'Ruth Avila' -- MA242 */
	(2041, 7029026, 8013495), /* 170: 'Edward Poon' and 'Eric Babcock' -- MA242 */
	(2041, 7029026, 8013495), /* 171: 'Edward Poon' and 'Eric Babcock' -- MA242 */
	(2041, 7029026, 8013495), /* 172: 'Edward Poon' and 'Eric Babcock' -- MA242 */
	(2041, 7098353, 8034929), /* 173: 'Cameron Williams' and 'Andrew Blankenship' -- MA242 */
	(2041, 7098353, 8034929), /* 174: 'Cameron Williams' and 'Andrew Blankenship' -- MA242 */
	(2041, 7098353, 8034929), /* 175: 'Cameron Williams' and 'Andrew Blankenship' -- MA242 */
	(2041, 7002342, 8091080), /* 176: 'Lara Ismert' and 'Georgiy Bondar' -- MA242 */
	(2041, 7002342, 8091080), /* 177: 'Lara Ismert' and 'Georgiy Bondar' -- MA242 */
	(2041, 7002342, 8091080), /* 178: 'Lara Ismert' and 'Georgiy Bondar' -- MA242 */
	(2042, 7098879, 8003461), /* 179: 'Wantanabe Tatsunari' and 'Bradyn Braithwaite' -- MA243 */
	(2042, 7098879, 8003461), /* 180: 'Wantanabe Tatsunari' and 'Bradyn Braithwaite' -- MA243 */
	(2042, 7098879, 8003461), /* 181: 'Wantanabe Tatsunari' and 'Bradyn Braithwaite' -- MA243 */
	(2042, 7090319, 8014901), /* 182: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 183: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 184: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 185: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 186: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 187: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 188: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 189: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2042, 7090319, 8014901), /* 190: 'Hisaya Tsutsui' and 'Michael Butler' -- MA243 */
	(2043, 7082343, 8030510), /* 191: 'Brent Soile' and 'Ashleigh Cook' -- MA345 */
	(2043, 7082343, 8030510), /* 192: 'Brent Soile' and 'Ashleigh Cook' -- MA345 */
	(2043, 7082343, 8030510), /* 193: 'Brent Soile' and 'Ashleigh Cook' -- MA345 */
	(2043, 7082343, 8030510), /* 194: 'Brent Soile' and 'Ashleigh Cook' -- MA345 */
	(2043, 7090319, 8023511), /* 195: 'Hisaya Tsutsui' and 'Tyler Stiff' -- MA345 */
	(2043, 7090319, 8023511), /* 196: 'Hisaya Tsutsui' and 'Tyler Stiff' -- MA345 */
	(2043, 7090319, 8023511), /* 197: 'Hisaya Tsutsui' and 'Tyler Stiff' -- MA345 */
	(2043, 7090319, 8023511), /* 198: 'Hisaya Tsutsui' and 'Tyler Stiff' -- MA345 */
	(2043, 7029026, 8013495), /* 199: 'Edward Poon' and 'Eric Babcock' -- MA345 */
	(2043, 7029026, 8013495), /* 200: 'Edward Poon' and 'Eric Babcock' -- MA345 */
	(2043, 7029026, 8013495), /* 201: 'Edward Poon' and 'Eric Babcock' -- MA345 */
	(2043, 7029026, 8013495), /* 202: 'Edward Poon' and 'Eric Babcock' -- MA345 */
	(2044, 7012399, 8023490), /* 203: 'John Sevic' and 'Cortes Crawford' --  EGR115 */
	(2044, 7012399, 8023490), /* 204: 'John Sevic' and 'Cortes Crawford' --  EGR115 */
	(2044, 7012399, 8023490), /* 205: 'John Sevic' and 'Cortes Crawford' --  EGR115 */
	(2044, 7029321, 8013840), /* 206: 'Shigeo Hayashibara' and 'Chase Davis' --  EGR115 */
	(2044, 7029321, 8013840), /* 207: 'Shigeo Hayashibara' and 'Chase Davis' --  EGR115 */
	(2044, 7029321, 8013840), /* 208: 'Shigeo Hayashibara' and 'Chase Davis' --  EGR115 */
	(2044, 7002347, 8003454), /* 209: 'Joel Schipper' and 'Christina Corliss' --  EGR115 */
	(2044, 7002347, 8003454), /* 210: 'Joel Schipper' and 'Christina Corliss' --  EGR115 */
	(2044, 7002347, 8003454), /* 211: 'Joel Schipper' and 'Christina Corliss' --  EGR115 */
	(2044, 7012347, 8013481), /* 212: 'Atanu Halder' and 'Spencer Davis' --  EGR115 */
	(2044, 7012347, 8013481), /* 213: 'Atanu Halder' and 'Spencer Davis' --  EGR115 */
	(2044, 7012347, 8013481), /* 214: 'Atanu Halder' and 'Spencer Davis' --  EGR115 */
	(2044, 7012347, 8013481), /* 215: 'Atanu Halder' and 'Spencer Davis' --  EGR115 */
	(2045, 7003491, 8094987), /* 216: 'Hadi Ali' and 'Kate Delany' --  EGR200 */
	(2045, 7003491, 8094987), /* 217: 'Hadi Ali' and 'Kate Delany' --  EGR200 */
	(2045, 7003491, 8094987), /* 218: 'Hadi Ali' and 'Kate Delany' --  EGR200 */
	(2045, 7003491, 8094987), /* 219: 'Hadi Ali' and 'Kate Delany' --  EGR200 */
	(2045, 7023911, 8058210), /* 220: 'Joseph Smith' and 'Andrew Erickson' --  EGR200 */
	(2045, 7023911, 8058210), /* 221: 'Joseph Smith' and 'Andrew Erickson' --  EGR200 */
	(2045, 7023911, 8058210), /* 222: 'Joseph Smith' and 'Andrew Erickson' --  EGR200 */
	(2045, 7023911, 8058210), /* 223: 'Joseph Smith' and 'Andrew Erickson' --  EGR200 */
	(2046, 7083210, 8342841), /* 224: 'Jesse Chiu' and 'Alexandra Ralph' -- CS213 */
	(2046, 7083210, 8342841), /* 225: 'Jesse Chiu' and 'Alexandra Ralph' -- CS213 */
	(2047, 7083210, 8342841), /* 226: 'Jesse Chiu' and 'Alexandra Ralph' -- CI119 */
	(2047, 7083210, 8342841), /* 227: 'Jesse Chiu' and 'Alexandra Ralph' -- CI119 */
	(2048, 7083210, 8034971), /* 228: 'Jesse Chiu' and 'Paige Thompson' -- CI120 */
	(2049, 7083210, 8034971), /* 229: 'Jesse Chiu' and 'Paige Thompson' -- CI311 */
	(2050, 7083210, 8034971); /* 230: 'Jesse Chiu' and 'Paige Thompson' -- CI490 */

CREATE TABLE IF NOT EXISTS long_sessions(
	sessionID INT NOT NULL AUTO_INCREMENT,
	tutorID INT NOT NULL,
	sectionID INT NOT NULL,
	session_time DATETIME,
	building VARCHAR(15),
	room VARCHAR(10),
	PRIMARY KEY(sessionID));
	
/* 850 sessions total */	
INSERT INTO long_sessions
	(tutorID, sectionID, session_time, building, room) VALUES
	/* Monday */
	(8076441, 100, '2021-01-10 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-10 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-10 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-10 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-10 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-10 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-10 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-10 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-10 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-10 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-10 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-10 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-10 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-01-11 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-01-11 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-01-11 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-01-11 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-01-11 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-01-11 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-01-11 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-01-11 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-01-11 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-01-11 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-01-11 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-01-11 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-01-11 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-01-11 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-01-11 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-01-12 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-01-12 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-01-12 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-01-12 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-01-12 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-01-12 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-01-12 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-01-12 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-01-12 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-01-13 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-01-13 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-01-13 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-01-13 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-01-13 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-01-13 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-01-13 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-01-13 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-01-13 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-01-13 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-01-13 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-01-13 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-01-13 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-01-17 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-17 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-17 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-17 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-17 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-17 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-17 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-17 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-17 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-17 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-17 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-17 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-17 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-01-18 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-01-18 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-01-18 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-01-18 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-01-18 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-01-18 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-01-18 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-01-18 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-01-18 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-01-18 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-01-18 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-01-18 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-01-18 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-01-18 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-01-18 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-01-19 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-01-19 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-01-19 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-01-19 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-01-19 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-01-19 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-01-19 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-01-19 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-01-19 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-01-20 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-01-20 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-01-20 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-01-20 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-01-20 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-01-20 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-01-20 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-01-20 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-01-20 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-01-20 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-01-20 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-01-20 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-01-20 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-01-24 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-24 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-24 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-24 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-24 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-24 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-24 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-24 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-24 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-24 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-24 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-24 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-24 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-01-25 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-01-25 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-01-25 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-01-25 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-01-25 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-01-25 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-01-25 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-01-25 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-01-25 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-01-25 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-01-25 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-01-25 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-01-25 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-01-25 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-01-25 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-01-26 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-01-26 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-01-26 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-01-26 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-01-26 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-01-26 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-01-26 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-01-26 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-01-26 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-01-27 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-01-27 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-01-27 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-01-27 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-01-27 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-01-27 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-01-27 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-01-27 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-01-27 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-01-27 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-01-27 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-01-27 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-01-27 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-01-31 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-31 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-31 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-31 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-31 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-31 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-31 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-31 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-31 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-31 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-31 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-31 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-31 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-02-01 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-02-01 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-02-01 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-02-01 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-02-01 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-02-01 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-02-01 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-02-01 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-02-01 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-02-01 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-02-01 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-02-01 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-02-01 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-02-01 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-02-01 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-02-02 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-02-02 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-02-02 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-02-02 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-02-02 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-02-02 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-02-02 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-02-02 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-02-02 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-02-03 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-02-03 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-02-03 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-02-03 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-02-03 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-02-03 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-02-03 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-02-03 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-02-03 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-02-03 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-02-03 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-02-03 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-02-03 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-02-07 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-02-07 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-02-07 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-02-07 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-02-07 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-02-07 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-02-07 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-02-07 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-02-07 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-02-07 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-02-07 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-02-07 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-02-07 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-02-08 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-02-08 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-02-08 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-02-08 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-02-08 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-02-08 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-02-08 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-02-08 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-02-08 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-02-08 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-02-08 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-02-08 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-02-08 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-02-08 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-02-08 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-02-09 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-02-09 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-02-09 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-02-09 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-02-09 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-02-09 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-02-09 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-02-09 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-02-09 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-02-10 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-02-10 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-02-10 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-02-10 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-02-10 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-02-10 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-02-10 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-02-10 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-02-10 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-02-10 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-02-10 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-02-10 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-02-10 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-02-14 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-02-14 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-02-14 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-02-14 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-02-14 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-02-14 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-02-14 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-02-14 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-02-14 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-02-14 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-02-14 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-02-14 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-02-14 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-02-15 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-02-15 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-02-15 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-02-15 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-02-15 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-02-15 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-02-15 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-02-15 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-02-15 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-02-15 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-02-15 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-02-15 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-02-15 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-02-15 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-02-15 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-02-16 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-02-16 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-02-16 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-02-16 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-02-16 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-02-16 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-02-16 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-02-16 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-02-16 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-02-17 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-02-17 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-02-17 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-02-17 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-02-17 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-02-17 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-02-17 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-02-17 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-02-17 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-02-17 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-02-17 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-02-17 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-02-17 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-02-21 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-02-21 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-02-21 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-02-21 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-02-21 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-02-21 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-02-21 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-02-21 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-02-21 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-02-21 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-02-21 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-02-21 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-02-21 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-02-22 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-02-22 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-02-22 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-02-22 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-02-22 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-02-22 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-02-22 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-02-22 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-02-22 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-02-22 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-02-22 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-02-22 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-02-22 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-02-22 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-02-22 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-02-23 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-02-23 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-02-23 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-02-23 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-02-23 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-02-23 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-02-23 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-02-23 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-02-23 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-02-24 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-02-24 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-02-24 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-02-24 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-02-24 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-02-24 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-02-24 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-02-24 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-02-24 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-02-24 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-02-24 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-02-24 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-02-24 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-02-28 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-02-28 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-02-28 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-02-28 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-02-28 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-02-28 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-02-28 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-02-28 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-02-28 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-02-28 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-02-28 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-02-28 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-02-28 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-01 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-01 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-01 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-01 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-01 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-01 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-01 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-01 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-01 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-01 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-01 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-01 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-01 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-01 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-01 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-02 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-02 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-02 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-02 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-02 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-02 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-02 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-02 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-02 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-03 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-03 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-03 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-03 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-03 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-03 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-03 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-03 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-03 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-03 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-03 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-03 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-03 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-03-07 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-03-07 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-03-07 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-03-07 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-03-07 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-03-07 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-03-07 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-03-07 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-03-07 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-03-07 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-03-07 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-03-07 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-03-07 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-08 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-08 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-08 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-08 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-08 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-08 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-08 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-08 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-08 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-08 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-08 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-08 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-08 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-08 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-08 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-09 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-09 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-09 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-09 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-09 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-09 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-09 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-09 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-09 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-10 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-10 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-10 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-10 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-10 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-10 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-10 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-10 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-10 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-10 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-10 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-10 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-10 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-03-14 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-03-14 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-03-14 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-03-14 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-03-14 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-03-14 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-03-14 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-03-14 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-03-14 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-03-14 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-03-14 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-03-14 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-03-14 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-15 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-15 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-15 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-15 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-15 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-15 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-15 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-15 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-15 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-15 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-15 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-15 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-15 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-15 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-15 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-16 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-16 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-16 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-16 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-16 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-16 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-16 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-16 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-16 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-17 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-17 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-17 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-17 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-17 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-17 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-17 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-17 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-17 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-17 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-17 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-17 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-17 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-03-21 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-03-21 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-03-21 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-03-21 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-03-21 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-03-21 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-03-21 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-03-21 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-03-21 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-03-21 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-03-21 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-03-21 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-03-21 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-22 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-22 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-22 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-22 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-22 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-22 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-22 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-22 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-22 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-22 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-22 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-22 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-22 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-22 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-22 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-23 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-23 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-23 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-23 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-23 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-23 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-23 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-23 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-23 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-24 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-24 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-24 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-24 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-24 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-24 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-24 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-24 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-24 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-24 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-24 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-24 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-24 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-03-28 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-03-28 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-03-28 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-03-28 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-03-28 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-03-28 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-03-28 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-03-28 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-03-28 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-03-28 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-03-28 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-03-28 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-03-28 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-03-29 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-03-29 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-03-29 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-03-29 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-03-29 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-03-29 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-03-29 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-03-29 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-03-29 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-03-29 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-03-29 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-03-29 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-03-29 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-03-29 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-03-29 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-03-30 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-03-30 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-03-30 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-03-30 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-03-30 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-03-30 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-03-30 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-03-30 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-03-30 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */	
	/* Thursday */
	(8023511, 6, '2021-03-31 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-03-31 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-03-31 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-03-31 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-03-31 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-03-31 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-03-31 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-03-31 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-03-31 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-03-31 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-03-31 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-03-31 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-03-31 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-04-04 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-04-04 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-04-04 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-04-04 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-04-04 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-04-04 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-04-04 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-04-04 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-04-04 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-04-04 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-04-04 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-04-04 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-04-04 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-04-05 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-04-05 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-04-05 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-04-05 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-04-05 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-04-05 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-04-05 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-04-05 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-04-05 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-04-05 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-04-05 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-04-05 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-04-05 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-04-05 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-04-05 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-04-06 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-04-06 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-04-06 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-04-06 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-04-06 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-04-06 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-04-06 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-04-06 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-04-06 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-04-07 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-04-07 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-04-07 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-04-07 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-04-07 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-04-07 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-04-07 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-04-07 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-04-07 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-04-07 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-04-07 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-04-07 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-04-07 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-04-11 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-04-11 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-04-11 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-04-11 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-04-11 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-04-11 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-04-11 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-04-11 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-04-11 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-04-11 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-04-11 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-04-11 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-04-11 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-04-12 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-04-12 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-04-12 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-04-12 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-04-12 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-04-12 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-04-12 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-04-12 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-04-12 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-04-12 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-04-12 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-04-12 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-04-12 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-04-12 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-04-12 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-04-13 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-04-13 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-04-13 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-04-13 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-04-13 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-04-13 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-04-13 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-04-13 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-04-13 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-04-14 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-04-14 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-04-14 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-04-14 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-04-14 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-04-14 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-04-14 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-04-14 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-04-14 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-04-14 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-04-14 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-04-14 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-04-14 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-04-18 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-04-18 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-04-18 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-04-18 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-04-18 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-04-18 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-04-18 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-04-18 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-04-18 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-04-18 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-04-18 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-04-18 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-04-18 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-04-19 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-04-19 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-04-19 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-04-19 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-04-19 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-04-19 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-04-19 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-04-19 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-04-19 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-04-19 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-04-19 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-04-19 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-04-19 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-04-19 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-04-19 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-04-20 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-04-20 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-04-20 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-04-20 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-04-20 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-04-20 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-04-20 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-04-20 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-04-20 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-04-21 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-04-21 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-04-21 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-04-21 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-04-21 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-04-21 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-04-21 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-04-21 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-04-21 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-04-21 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-04-21 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-04-21 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-04-21 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-04-25 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-04-25 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-04-25 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-04-25 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-04-25 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-04-25 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-04-25 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-04-25 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-04-25 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-04-25 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-04-25 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-04-25 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-04-25 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-04-26 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-04-26 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-04-26 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-04-26 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-04-26 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-04-26 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-04-26 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-04-26 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-04-26 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-04-26 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-04-26 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-04-26 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-04-26 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-04-26 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-04-26 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-04-27 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-04-27 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-04-27 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-04-27 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-04-27 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-04-27 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-04-27 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-04-27 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-04-27 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-04-28 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-04-28 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-04-28 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-04-28 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-04-28 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-04-28 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-04-28 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-04-28 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-04-28 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-04-28 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-04-28 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-04-28 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-04-28 19:00:00', 'Building 4', 'Room 105'), /* 50: 'Carson Yinger' CS118 */
	/* Monday */
	(8076441, 100, '2021-05-02 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-05-02 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-05-02 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-05-02 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-05-02 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-05-02 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-05-02 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-05-02 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-05-02 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-05-02 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-05-02 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-05-02 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-05-02 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */	
	/* Tuesday */
	(8003454, 141, '2021-05-03 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-05-03 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-05-03 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-05-03 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-05-03 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-05-03 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-05-03 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-05-03 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-05-03 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-05-03 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-05-03 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-05-03 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-05-03 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-05-03 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-05-03 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */	
	/* Wednesday */
	(8002347, 89, '2021-05-04 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-05-04 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-05-04 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-05-04 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-05-04 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-05-04 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-05-04 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-05-04 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-05-04 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	/* Thursday */
	(8023511, 6, '2021-05-05 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-05-05 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-05-05 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-05-05 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-05-05 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-05-05 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-05-05 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-05-05 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-05-05 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-05-05 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-05-05 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-05-05 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-05-05 19:00:00', 'Building 4', 'Room 105'); /* 50: 'Carson Yinger' CS118 */
	
CREATE TABLE IF NOT EXISTS tutors (
	tutorID INT NOT NULL,
	name VARCHAR(35),
	email VARCHAR(20),
	gradYear INT,
	PRIMARY KEY(tutorID));

/* 45 tutors total */
INSERT INTO tutors
	(tutorID, name, email, gradYear) VALUES
	(8034971, 'Paige Thompson', 'thompp13@my.erau.edu', 2023),
	(8005679, 'Cordaellia Farrell', 'farrelc2@my.erau.edu', 2023 ),
	(8006782, 'Brandon Todd', 'toddb3@my.erau.edu', 2023 ),
	(8003454, 'Christina Corliss', 'corlissc@my.erau.edu', 2023 ),
	(8000345, 'Alex Santalov', 'santaloa@my.erau.edu', 2022),
	(8046346, 'Thomas Dewald', 'dewaldt@my.erau.edu', 2022),
	(8045647, 'Gabriael Moore', 'mooreg15@my.erau.edu', 2024),
	(8054758, 'Amanda Goodbody', 'goodboda@my.erau.edu', 2024),
	(8000009, 'Jordan Owens', 'owensj31@my.erau.edu', 2024),
	(8056760, 'Brian Zelt', 'zeltb@my.erau.edu', 2023),
	(8023511, 'Tyler Stiff', 'stifft@my.erau.edu', 2022),
	(8056761, 'Hayden Roszell', 'roszellh@my.erau.edu', 2023),
	(8000346, 'Jake Whitaker', 'whitakj9@my.erau.edu', 2023),
	(8045814, 'Benjamin Sheldon', 'sheldob2@my.erau.edu', 2023),
	(8002385, 'Nathan Burk', 'burkn@my.erau.edu', 2023),
	(8000016, 'Ryan Begley', 'begleyr@my.erau.edu', 2023),
	(8002347, 'Angel Appelzoller', 'appelzoa@my.erau.edu', 2024),
	(8002348, 'Issac Juan', 'juani@my.erau.edu', 2025),
	(8056749, 'Nathan Kruger', 'krugern@my.erau.edu', 2025),
	(8034660, 'Katie Sugiyama', 'sugiyamk@my.erau.edu', 2025),
	(8076441, 'Carson Yinger', 'yingerc@my.erau.edu', 2025),
	(8007844, 'Sarah Chinn', 'chinns@my.erau.edu', 2025),
	(8002349, 'Caleb Loomis', 'loomisc2@my.erau.edu', 2024),
	(8008465, 'Hunter Nudson', 'nudsonh@my.erau.edu', 2024),
	(8149204, 'Courtney Nelson', 'nelsoc32@my.erau.edu', 2022),
	(8095493, 'Joshua Parmenter', 'parmentj@my.erau.edu', 2022),
	(8009543, 'Alexa Dunaisky', 'dunaiska@my.erau.edu', 2022),
	(8002355, 'Jacob Hindmarsh', 'hindmarj@my.erau.edu', 2023),
	(8030249, 'Clarissa Winks', 'winksc@my.erau.edu', 2023),
	(8094569, 'Sarah Reiter', 'reiters1@my.erau.edu', 2023),
	(8043092, 'Hamad Aloud', 'aloudh@my.erau.edu', 2023),
	(8092341, 'Kevin Anderson', 'anderk52@my.erau.edu', 2023),
	(8014934, 'Ruth Avila', 'avilar6@my.erau.edu', 2023),
	(8013495, 'Eric Babcock', 'babcoce1@my.erau.edu', 2022),
	(8034929, 'Andrew Blankenship', 'blankea3@my.erau.edu', 2024),
	(8091080, 'Georgiy Bondar', 'bondarg@my.erau.edu', 2023),
	(8003461, 'Bradyn Braithwaite', 'braithb1@my.erau.edu', 2024), 
	(8014901, 'Michael Butler', 'butlem11@my.erau.edu', 2022),
	(8030510, 'Ashleigh Cook', 'cooka14@my.erau.edu', 2022),
	(8023490, 'Cortes Crawford', 'crawfc21@my.erau.edu', 2023),
	(8013840, 'Chase Davis', 'johnsk90@my.erau.edu', 2023),
	(8013481, 'Spencer Davis', 'daviss76@my.erau.edu', 2024),
	(8094987, 'Kate Delany', 'delaneyk@my.erau.edu', 2023),
	(8058210, 'Andrew Erickson', 'ericksa6@my.erau.edu', 2023),
	(8342841, 'Alexandra Ralph', 'ralpha2@my.erau.edu', 2023);
	
CREATE TABLE IF NOT EXISTS sessions(
	sessionID INT NOT NULL AUTO_INCREMENT,
	tutorID INT NOT NULL,
	sectionID INT NOT NULL,
	session_time DATETIME,
	building VARCHAR(15),
	room VARCHAR(10),
	PRIMARY KEY(sessionID));
	
/* 	Will be all common lower-level (gen ed) courses because they are 
	pre-scheduled for high-volume subjects */
INSERT INTO sessions
	(tutorID, sectionID, session_time, building, room) VALUES
	(8076441, 100, '2021-01-11 19:00:00', 'Building 1', 'Room 100'), /* 1: 'Carson Yinger' PS150 */
	(8149204, 101, '2021-01-11 19:00:00', 'Building 1', 'Room 101'), /* 2: 'Courtney Nelson' PS150 */
	(8095493, 104, '2021-01-11 19:00:00', 'Building 1', 'Room 102'), /* 3: 'Joshua Parmenter' PS150 */
	(8009543, 108, '2021-01-11 19:00:00', 'Building 1', 'Room 103'), /* 4: 'Alexa Dunaisky' PS150 */
	(8002355, 113, '2021-01-11 19:00:00', 'Building 2', 'Room 123'), /* 5: 'Jacob Hindmarsh' PS150 */
	(8054758, 117, '2021-01-11 19:00:00', 'Building 2', 'Room 124'), /* 6: 'Amanda Goodbody' PS150 */
	(8000346, 121, '2021-01-11 19:00:00', 'Building 2', 'Room 125'), /* 7: 'Jake Whitaker' PS150 */
	(8046346, 125, '2021-01-11 19:00:00', 'Building 3', 'Room 210'), /* 8: 'Thomas Dewald' PS160 */
	(8034971, 129, '2021-01-11 19:00:00', 'Building 3', 'Room 211'), /* 9: 'Paige Thompson' PS160 */
	(8023511, 133, '2021-01-11 19:00:00', 'Building 3', 'Room 212'), /* 10: 'Tyler Stiff' PS160 */
	(8000345, 137, '2021-01-11 19:00:00', 'Building 3', 'Room 213'), /* 11: 'Alex Santalov' PS160 */
	(8002385, 68, '2021-01-11 19:00:00', 'Building 4', 'Room 101'), /* 12: 'Nathan Burk' PS250 */
	(8002347, 70, '2021-01-11 19:00:00', 'Building 4', 'Room 102'), /* 13: 'Angel Appelzoller' PS250 */
	(8003454, 141, '2021-01-12 19:00:00', 'Building 1', 'Room 100'), /* 14: 'Christina Corliss' MA241 */
	(8005679, 144, '2021-01-12 19:00:00', 'Building 1', 'Room 101'), /* 15: 'Cordaellia Farrell' MA241 */
	(8007844, 147, '2021-01-12 19:00:00', 'Building 1', 'Room 102'), /* 16: 'Sarah Chinn' MA241 */
	(8094569, 153, '2021-01-12 19:00:00', 'Building 2', 'Room 123'), /* 17: 'Sarah Reiter' MA242 */
	(8043092, 157, '2021-01-12 19:00:00', 'Building 2', 'Room 124'), /* 18: 'Hamad Aloud' MA242 */
	(8092341, 161, '2021-01-12 19:00:00', 'Building 2', 'Room 125'), /* 19: 'Kevin Anderson' MA242 */
	(8014934, 166, '2021-01-12 19:00:00', 'Building 3', 'Room 210'), /* 20: 'Ruth Avila' MA242 */
	(8013495, 170, '2021-01-12 19:00:00', 'Building 3', 'Room 211'), /* 21: 'Eric Babcock' MA242 */
	(8034929, 173, '2021-01-12 19:00:00', 'Building 3', 'Room 212'), /* 22: 'Andrew Blankenship' MA242 */
	(8091080, 176, '2021-01-12 19:00:00', 'Building 3', 'Room 213'), /* 23: 'Georgiy Bondar' MA242 */
	(8003461, 179, '2021-01-12 19:00:00', 'Building 4', 'Room 101'), /* 24: 'Bradyn Braithwaite' MA243 */
	(8014901, 182, '2021-01-12 19:00:00', 'Building 4', 'Room 102'), /* 25: 'Michael Butler' MA243 */
	(8030510, 191, '2021-01-12 19:00:00', 'Building 4', 'Room 103'), /* 26: 'Ashleigh Cook' MA345 */
	(8023511, 195, '2021-01-12 19:00:00', 'Building 4', 'Room 104'), /* 27: 'Tyler Stiff' MA345 */
	(8013495, 199, '2021-01-12 19:00:00', 'Building 4', 'Room 105'), /* 28: 'Eric Babcock' MA345 */
	(8002347, 89, '2021-01-13 19:00:00', 'Building 1', 'Room 100'), /* 29: 'Angel Appelzoller' UNIV101 */
	(8002349, 90, '2021-01-13 19:00:00', 'Building 1', 'Room 101'), /* 30: 'Caleb Loomis' UNIV101 */
	(8008465, 94, '2021-01-13 19:00:00', 'Building 1', 'Room 102'), /* 31: 'Hunter Nudson' UNIV101 */
	(8034660, 80, '2021-01-13 19:00:00', 'Building 2', 'Room 123'), /* 32: 'Katie Sugiyama' COM221 */
	(8076441, 83, '2021-01-13 19:00:00', 'Building 2', 'Room 124'), /* 33: 'Carson Yinger' COM221 */
	(8007844, 86, '2021-01-13 19:00:00', 'Building 2', 'Room 125'), /* 34: 'Sarah Chinn' COM221 */
	(8002385, 59, '2021-01-13 19:00:00', 'Building 3', 'Room 210'), /* 35: 'Nathan Burk' HU330 */
	(8002347, 62, '2021-01-13 19:00:00', 'Building 3', 'Room 211'), /* 36: 'Angel Appelzoller' HU330 */
	(8002348, 65, '2021-01-13 19:00:00', 'Building 3', 'Room 212'), /* 37: 'Issac Juan' HU330 */
	(8023511, 6, '2021-01-14 19:00:00', 'Building 1', 'Room 100'), /* 38: 'Tyler Stiff' CEC 220 */
	(8005679, 7, '2021-01-14 19:00:00', 'Building 1', 'Room 101'), /* 39: 'Cordaellia Farrell' CEC 220 */
	(8006782, 9, '2021-01-14 19:00:00', 'Building 1', 'Room 102'), /* 40: 'Brandon Todd' CEC 220 */
	(8056760, 41, '2021-01-14 19:00:00', 'Building 2', 'Room 123'), /* 41: 'Brian Zelt' EE335 */
	(8056761, 43, '2021-01-14 19:00:00', 'Building 2', 'Room 124'), /* 42: 'Hayden Roszell' EE335 */
	(8000346, 45, '2021-01-14 19:00:00', 'Building 2', 'Room 125'), /* 43: 'Jake Whitaker' EE335 */
	(8094987, 216, '2021-01-14 19:00:00', 'Building 3', 'Room 210'), /* 44: 'Kate Delany' EGR200 */
	(8058210, 220, '2021-01-14 19:00:00', 'Building 3', 'Room 211'), /* 45: 'Andrew Erickson' EGR200 */
	(8023490, 203, '2021-01-14 19:00:00', 'Building 4', 'Room 101'), /* 46: 'Cortes Crawford' EGR115 */
	(8013840, 206, '2021-01-14 19:00:00', 'Building 4', 'Room 102'), /* 47: 'Chase Davis' EGR115 */
	(8003454, 209, '2021-01-14 19:00:00', 'Building 4', 'Room 103'), /* 48: 'Christina Corliss' EGR115 */
	(8013481, 212, '2021-01-14 19:00:00', 'Building 4', 'Room 104'), /* 49: 'Spencer Davis' EGR115 */
	(8076441, 20, '2021-01-14 19:00:00', 'Building 4', 'Room 105'); /* 50: 'Carson Yinger' CS118 */

/* Physics Department Gets Mondays. */
/* Math Department Gets Tuesdays. */
/* Humanities Department Gets Wednesdays. */
/* Engineering Department Gets Thursdays. */
/* Fridays-Saturdays left open for Appointments */
/* Labs left for appointments */

CREATE TABLE IF NOT EXISTS students (
	studentID INT NOT NULL,
	name VARCHAR(35),
	email VARCHAR(20),
	gradYear INT,
	PRIMARY KEY(studentID));

/* 30 students total */
INSERT INTO students
	(studentID, name, email, gradYear) VALUES
	(9001234, 'Connor Algeri', 'algeric@my.erau.edu', 2024),
	(9013577, 'Anivartin Anand', 'ananda@my.erau.edu', 2020),
	(9001122, 'Jack Bauer', 'bauerj12@my.erau.edu', 2020),
	(9000074, 'Zackary Lally', 'bauerz3@my.erau.edu', 2024 ),
	(9100238, 'Ryan Beegle', 'beegler@my.erau.edu', 2022),
	(9004382, 'Patrick Coulon', 'coulonp1@my.erau.edu', 2025),
	(9006748, 'Kobie Deleonard', 'deleonak@my.erau.edu', 2024),
	(9010101, 'James Frost', 'frostj9@my.erau.edu', 2024),
	(9000346, 'Zachary Garcia', 'garciaz1@my.erau.edu', 2024),
	(9002022, 'Joseph Guerrera', 'guerrej8@my.erau.edu', 2024),
	(9144800, 'Nathan Ha', 'han@my.erau.edu', 2022),
	(9111827, 'Jacob Hart', 'hartj32@my.erau.edu', 2024),
	(9001836, 'Karim Hernandez', 'hernak20@my.erau.edu', 2024),
	(9010204, 'Gabrielle Johnson', 'johsg50@my.erau.edu', 2024),
	(9000006, 'Jimmall Kincaid', 'kincaij6@my.erau.edu', 2024),
	(9002877, 'Ethan Kriel', 'kriele@my.erau.edu', 2024),
	(9098005, 'Kyle LaClair', 'laclairk@my.erau.edu', 2024),
	(9007858, 'Aidan Maney', 'maneya@my.erau.edu', 2025),
	(9009709, 'Dominik Martinez', 'martd127@my.erau.edu', 2025),
	(9000307, 'Gonzolo Palomares', 'palomarg@my.erau.edu', 2025),
	(9005432, 'Hannah Pehl', 'pehlh@my.erau.edu', 2025),
	(9003049, 'Matthew Pierce', 'piercm12@my.erau.edu', 2025),
	(9030292, 'Mckenna Rendig', 'rendigm@my.erau.edu', 2020),
	(9112294, 'Tomas Schweitzer', 'schweitt@my.erau.edu', 2024),
	(9002065, 'Alexander Simmons', 'simmoa14@my.erau.edu', 2025),
	(9002255, 'Jacob Sander', 'sandej39@my.erau.edu', 2025),
	(9001436, 'Gabriel Rodriguez', 'rodrig45@my.erau.edu', 2025),
	(9058788, 'Eva Hansen', 'hanse82@my.erau.edu', 2024),
	(9038295, 'Kate Shriki', 'shrikik@.my.erau.edu', 2022),
	(9034902, 'Janessa Slone', 'slonej1@my.erau.edu', 2023);
	
CREATE TABLE IF NOT EXISTS subjects (
	classID INT NOT NULL, 
	courseNum VARCHAR(8),
	name VARCHAR(55),
	credits INT NOT NULL,
	PRIMARY KEY(classID));

/* 50 subjects total */
INSERT INTO subjects
	(classID, courseNum, name, credits) VALUES
	(2001, 'AE302', 'Aerodynamics II', 3),
	(2002, 'AE318', 'Aerospace Structures I', 3),
	(2003, 'AE430', 'Control System Analysis and Design', 3),
	(2004, 'CS317', 'Files and Database Systems', 3),
	(2005, 'CEC320', 'Microprocessors', 3),
	(2006, 'CEC220', 'Digital Circuits', 3),
	(2007, 'CEC223', 'Digital Circuits Laboratory', 1),
	(2008, 'CS420', 'Operating Systems', 3),
	(2009, 'CE460', 'Telecommunications Systems', 3),
	(2010, 'CE470', 'Computer Architecture', 3),
	(2011, 'CS315', 'Data Structures and Algorithms', 3),
	(2012, 'CS118', 'Fundamentals of Computer Programming', 3),
	(2013, 'CS125', 'Computer Science I', 3),
	(2014, 'CS225', 'Computer Science II', 4),
	(2015, 'CS225L', 'Computer Science II Laboratory', 0),
	(2016, 'CS332', 'Organization of Programming Languages', 3),
	(2017, 'CS432', 'Information and Computer Security', 3),
	(2018, 'SE300', 'Software Engineering Practices', 3),
	(2019, 'ES201', 'Statics', 3),
	(2020, 'ES202', 'Solid Mechanics', 3),
	(2021, 'ES204', 'Dynamics', 3),
	(2022, 'ES205', 'Thermodynamics', 3),
	(2023, 'ES206', 'Fluid Mechanics', 3),
	(2024, 'SE310', 'Analysis and Design of Software Systems', 3),
	(2025, 'SE420', 'Software Quality Assurance', 3),
	(2026, 'MA412', 'Probability and Statistics', 3),
	(2027, 'EE335', 'Electrical Engineering I', 2),
	(2028, 'EE336', 'Electrical Engineering I Laboratory', 1),
	(2029, 'EC225', 'Engineering Economics', 3),
	(2030, 'HU330', 'Values and Ethics', 3),
	(2031, 'PS250', 'Physics III',3),
	(2032, 'SE320', 'Software Construction', 3),
	(2033, 'EGR101', 'Intro to Engineering', 3),
	(2034, 'COM221', 'Technical Report Writing', 3),
	(2035, 'UNIV101', 'College Success', 1),
	(2036, 'MA225', 'Discrete Structures', 3),
	(2037, 'ME309', 'Airbreathing & Rocket Propulsion', 3),
	(2038, 'PS150', 'Physics I for Engineers', 3),
	(2039, 'PS160', 'Physics II for Engineers', 3),
	(2040, 'MA241', 'Calculus and Analytical Geometry I', 4),
	(2041, 'MA242', 'Calculus and Analytical Geometry II', 4),
	(2042, 'MA243', 'Calculus and Analytical Geometry III', 4),
	(2043, 'MA345', 'Differential Equations and Matrix Methods', 4),
	(2044, 'EGR115', 'Introduction to Computing for Engineers', 3),
	(2045, 'EGR200', 'Computer Aided Conceptual Design of Aerospace Systems', 3),
	(2046, 'CS213', 'Introduction to Computer Networks', 3),
	(2047, 'CI119', 'Introduction to Cybersecurity for Non-Majors', 3),
	(2048, 'CI120', 'Introduction to Cybersecurity for Majors', 3),
	(2049, 'CI311', 'Securing Computer Networks', 3),
	(2050, 'CI490', 'Cyber Capstone Project', 3);

CREATE TABLE IF NOT EXISTS teachers (
	employeeID INT NOT NULL,
	name VARCHAR(40),
	email VARCHAR(25),
	PRIMARY KEY(employeeID));

/* 65 total teachers */
INSERT INTO teachers
	(employeeID, name, email) VALUES
	(7034971, 'Michael Van Hilst','vanhilism@erau.edu' ),
	(7005679, 'Luis Zapata Rivera','zapatarl@erau.edu'),
	(7006782, 'Matthew Jaffe','jaffem@erau.edu'),
	(7003454, 'Heather Marriott','marric72@erau.edu'),
	(7000345, 'Christopher Briggs','briggsc1@erau.edu'),
	(7046346, 'Leeann Chen','chenl@erau.edu'),
	(7045647, 'Sameer Abufardeh','abufards@erau.edu'),
	(7054758, 'Hisaya Tstsui','tsuts157@erau.edu'),
	(7002347, 'Joel Schipper','schippej@erau.edu'),
	(7056760, 'Jules Yimga','yimgaj@erau.edu'),
	(7023511, 'Kelly Lambert','lamberk1@erau.edu'),
	(7056761, 'Michele Zanolin','zanolimn@erau.edu'),
	(7000014, 'Preston Jones','jonesp13@erau.edu'),
	(7002385, 'Scott Post','posts1@erau.edu'),
	(7002342, 'Lara Ismert', 'ismertl@erau.edu'),
	(7000016, 'Shigeo Hayashibara','hayasd87@erau.edu'),
	(7002323, 'John Matthew Pavlina', 'pavlinaj@erau.edu'),
	(7002131, 'Elliott Bryner', 'brynere@erau.edu'),
	(7002191, 'John Edward Post, Jr.', 'postj@erau.edu'),
	(7012311, 'Brenda Haven', 'havenb@erau.edu'),
	(7091381, 'Scott Post', 'posts1@erau.edu'),
	(7001223, 'Ken Anothony Bordignon', 'bordignk@erau.edu'),
	(7001088, 'Josef Penaovski', 'panovskij@erau.edu'),
	(7008128, 'Muna Slewa', 'slewam@erau.edu'),
	(7013084, 'Radek Glaser', 'glaserr@erau.edu'),
	(7098879, 'Wantanabe Tatsunari', 'wantanabt@erau.edu'),
	(7091283, 'Susan Rauch', 'rauchs1@erau.edu'),
	(7093284, 'Padraig Houlahan', 'houlahap@erau.edu'),
	(7002141, 'Elizabeth Gretarsson', 'jesse400@erau.edu'),
	(7093529, 'Dennis Kodimer', 'kodimerd@erau.edu'),
	(7032894, 'Michael McClure', 'mcclurm3@erau.edu'),
	(7019412, 'Joshua Sullins', 'sullinsj@erau.edu'),
	(7023841, 'Mary Beck', 'beckae0@erau.edu'),
	(7012318, 'Eric Kumpf', 'kumpfe@erau.edu'),
	(7012431, 'Ahmed Sulyman', 'sulymana@erau.edu'), 
	(7023483, 'Robert Olive', 'oliver1@erau.edu'),
	(7032942, 'John Sevic', 'sevicj@erau.edu'),
	(7048258, 'Seth McNeill', 'mcneils2@erau.edu'),
	(7034858, 'Timothy Callahan', 'callahat@erau.edu'),
	(7032841, 'Paul Bunnell', 'bunnellp@erau.edu'),
	(7034893, 'William MacKunis', 'macjuniw@erau.edu'),
	(7082609, 'Tomomi Otani', 'otanit@erau.edu'),
	(7034853, 'Katharine Moran', 'morank5@erau.edu'),
	(7084596, 'Bryan Armentrout', 'armentb1@erau.edu'),
	(7095832, 'Byonghoon Seo', 'seob1@erau.edu'),
	(7069403, 'Dan Maronde', 'maronded@erau.edu'),
	(7093243, 'Brian Rachford', 'rachf7ac@erau.edu'),
	(7079742, 'Quentin Bailey', 'baileyq@erau.edu'),	
	(7083405, 'Brent Spencer', 'spenceb3@erau.edu'),
	(7093467, 'Michelle Elghardgui', 'elghardm@erau.edu'),	
	(7098353, 'Cameron Williams', 'willc187@erau.edu'),
	(7094480, 'Jeri Hamilton', 'hamilj32@erau.edu'),
	(7034501, 'Jian Cheng', 'chengj5@erau.edu'),
	(7039883, 'Angelynn Alvarez', 'alvara44@erau.edu'),
	(7003235, 'Keke Wang', 'wangk5@erau.edu'),
	(7023408, 'Dean Holbrook', 'holbrod1@erau.edu'),
	(7029026, 'Edward Poon', 'poon3de@erau.edu'),
	(7090319, 'Hisaya Tsutsui', 'tsuts157@erau.edu'),
	(7082343, 'Brent Solie', 'solieb@erau.edu'),
	(7003491, 'Hadi Ali', 'alih9@erau.edu'),
	(7023911, 'Joseph Smith', 'smitj402@erau.edu'),
	(7012399, 'John Sevic', 'sevicj@erau.edu'),
	(7029321, 'Shigeo Hayashibara', 'hayasd87@my.erau.edu'),
	(7012347, 'Atanu Halder', 'haldera@erau.edu'),
	(7083210, 'Jesse Chiu', 'chiuj2@erau.edu');

/* starting digit of 1 indicates an appointmentID */
/* starting digit of 2 indicates a classID */
/* starting digit of 7 indicates a employeeID */
/* starting digit of 8 indicates a tutorID */
/* starting digit of 9 indicates a studentID */
/* sectionIDs and sessionIDs are auto_incremented */