from django.db import models

# Create your models here.

class appointments(models.Model):
    appointmentID = models.IntegerField(default = '',null=False)
    tutorID = models.IntegerField(default = '',null=False)
    studentID=models.IntegerField(default = '',null=False)
    sectionID = models.IntegerField(default = '',null=False)
    appointment_time =models.DateTimeField(auto_now_add=False,null=False,blank=True)
    building = models.CharField(default = '', null = False, max_length = 15)
    room = models.CharField(default = '',null = False, max_length = 10)
    class Meta:
        verbose_name_plural= 'appointments'
    def __str__(self):
        return self.appointments

class instructor(models.Model):
    classID = models.IntegerField(default = '',null=False)
    sectionID = models.IntegerField(default = '',null=False)
    tutorID = models.IntegerField(default = '',null=False)
    employeeID = models.IntegerField(default = '',null=False)
    class Meta:
        verbose_name_plural = 'instructors'
    def __str__(self):
        return self.instructor

class session(models.Model):
    sessionID = models.IntegerField(default = '',null=False)
    sectionID = models.IntegerField(default = '',null=False)
    tutorID = models.IntegerField(default = '',null=False)
    sessionTime = models.DateTimeField(default = '',auto_now_add=False,null=False)
    building = models.CharField(default = '', null = False, max_length = 15)
    room = models.CharField(default = '',null = False, max_length = 10)
    class Meta:
        verbose_name_plural = 'sessions'
    def __str__(self):
        return self.session

class student(models.Model):
    studentID = models.IntegerField(default = '',null=False)
    name = models.CharField(default = '',max_length=20,null=False)
    email = models.EmailField(default = '',max_length=40,null=False)
    gradYear = models.IntegerField(default = '',null=False)
    class Meta:
        verbose_name_plural = 'students'
    def __str__(self):
        return self.student
class subject(models.Model):
    classID = models.IntegerField(default = '',null=False)
    course_num = models.CharField(default = '',max_length=20,null=False)
    name = models.CharField(default = '',max_length=25,null=False)
    credits = models.IntegerField(default = '',null=False)
    class Meta:
        verbose_name_plural = 'subjects'
    def __str__(self):
        return self.subject
class teacher(models.Model):
    employeeID = models.IntegerField(default = '',null=False)
    name = models.CharField(default = '',max_length=20,null=False)
    email = models.EmailField(default = '',max_length=40,null=False)
    class Meta:
        verbose_name_plural = 'teachers'
    def __str__(self):
        return self.teacher