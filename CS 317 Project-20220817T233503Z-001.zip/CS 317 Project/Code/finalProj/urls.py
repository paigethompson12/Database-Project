"""finalProj URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name = 'index'),
    path('appointment_form/',views.appointment_form,name='appointment_form'),
    path('instructors_form/',views.instructors_form,name='instructors_form'),
    path('session_form/',views.session_form,name='session_form'),
    path('student_form/',views.student_form,name='student_form'),
    path('subject_form/',views.subject_form,name='subject_form'),
    path('teachers_form/',views.teachers_form,name='teachers_form'),
    path('teachers_info/',views.teacher_info,name='teachers_info'),
    path('subject_info/',views.subject_info,name='subject_info'),
    path('student_info/',views.student_info,name='student_info'),
    path('session_info/',views.session_info,name='session_info'),
    path('instructor_info/',views.instructor_info,name='instructor_info'),
    path('appointment_info/',views.appointment_info,name='appointment_info'),
    path('appointment_search/',views.appointment_query,name='appointment_query'),
    path('instructor_search/',views.instructors_query,name='instructor_query'),
    path('session_search/',views.session_query,name = 'session_query'),
    path('student_search/',views.student_query,name='student_query'),
    path('subject_search/',views.subject_query,name='subject_query'),
    path('teachers_search/',views.teachers_query,name='teachers_query'),
]
