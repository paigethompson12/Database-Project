from django.shortcuts import render,redirect 
from .models import *
import mysql.connector
import datetime

def index(request):
    return render(request, 'index.html')
def appointment_query(request):
    return render(request,'appointment_query.html')
def appointment_form(request):
    if request.method =='POST':
        print(request.POST)
        mydb = mysql.connector.connect(
            host='localhost',
            user='btodd',
            password='Seahawksbdrizzle1',
            database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "INSERT INTO appointments(appointmentID, tutorID, studentID, sectionID, appointment_time, building, room) VALUES(%s, %s, %s, %s, %s, %s, %s)"
        args = [int(request.POST['appointmentID']),int(request.POST['tutorID']),int(request.POST['studentID']),int(request.POST['sectionID']),datetime.datetime.strptime(request.POST['appointment_time'],"%Y-%m-%d %H:%M:%S"),request.POST['building'],request.POST['room']]
        cursor.execute(query, args)
        mydb.commit()
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    return render(request,'appointment_form.html')
def appointment_info(request):
    A = appointments()
    appointment = []
    if request.method=='POST':
        appointmentID = request.POST['appointmentID']
        tutorID = request.POST['tutorID']
        studentID = request.POST['studentID']
        sectionID = request.POST['sectionID']
        if(request.POST['appointment_time']=='' or request.POST['appointment_time']=='*'):
            appointment_time = request.POST['appointment_time']
            f = 0
        else:
            appointment_time = datetime.datetime.strptime(request.POST['appointment_time'],"%Y-%m-%d %H:%M:%S")
            f =1
        building = request.POST['building']
        room = request.POST['room']
        mydb = mysql.connector.connect(
                host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "SELECT * FROM appointments"
        cursor.execute(query)
        for result in cursor.fetchall():
                if(str(result['appointmentID'])==appointmentID or appointmentID=='' or appointmentID=='*'):
                    if (str(result['tutorID'])==tutorID or tutorID ==''or tutorID =='*'):
                        if(str(result['studentID'])==studentID or studentID ==''or studentID =='*'):
                            if(str(result['sectionID'])==sectionID or sectionID=='' or sectionID =='*'):
                                if((f==1 and result['appointment_time'] ==appointment_time) or (f==0 and (appointment_time=='' or appointment_time=='*'))):
                                    if(result['building']==building or building=='' or building =='*'):
                                        if(result['room']==room or room == '' or room=='*'):
                                            appointment.append({'appointmentID':result['appointmentID'],'tutorID':result['tutorID'],'studentID':result['studentID'],'sectionID': result['sectionID'],'appointment_time':result['appointment_time'],'building' : result['building'],'room' : result['room']})
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    context = {'Appointments':appointment}
    return render(request,'appointment_info.html',context) 
def instructors_query(request):
    return render(request,'instructor_query.html')
def instructors_form(request):
    if request.method =='POST':
        print(request.POST)
        mydb = mysql.connector.connect(
            host='localhost',
            user='btodd',
            password='Seahawksbdrizzle1',
            database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "INSERT INTO instructors_by_subject(classID, employeeID, tutorID) VALUES(%s,%s,%s)"
        args = [int(request.POST['classID']),int(request.POST['employeeID']),int(request.POST['tutorID'])]
        cursor.execute(query, args)
        mydb.commit()
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    return render(request,'instructor_form.html')
def instructor_info(request):
    I = instructor()
    instructors = []
    if request.method=='POST':
        sectionID = request.POST['sectionID']
        classID = request.POST['classID']
        employeeID = request.POST['employeeID']
        tutorID= request.POST['tutorID']
        mydb = mysql.connector.connect(
                host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "SELECT * FROM instructors_by_subject"
        cursor.execute(query)
        for result in cursor.fetchall():
            if(str(result['sectionID'])==sectionID or sectionID=='' or sectionID=='*'):
                if (str(result['classID'])==classID or classID ==''or classID =='*'):
                    if(str(result['employeeID'])==employeeID or employeeID ==''or employeeID =='*'):
                        if(str(result['tutorID'])==tutorID or tutorID=='' or tutorID =='*'):
                            instructors.append({'sectionID':result['sectionID'],'classID':result['classID'],'employeeID':result['employeeID'],'tutorID' : result['tutorID']})
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    context = {'Instructors':instructors}
    return render(request,'instructor_info.html',context) 
def session_query(request):
    return render(request,'session_query.html')
def session_form(request):
    if request.method =='POST':
        print(request.POST)
        mydb = mysql.connector.connect(
                host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor(dictionary=True,buffered=True)
        query = "INSERT INTO sessions(tutorID, sectionID, session_time, building, room) VALUES(%s, %s, %s, %s, %s)"
        dt_tuple=tuple([int(x) for x in request.POST['session_time'][:10].split('-')])+tuple([int(x) for x in request.POST['session_time'][11:].split(':')])
        print(datetime.datetime.strptime(request.POST['session_time'],"%Y-%m-%d %H:%M:%S"))
        args = [int(request.POST['tutorID']),int(request.POST['sectionID']),datetime.datetime.strptime(request.POST['session_time'],"%Y-%m-%d %H:%M:%S"),request.POST['building'],request.POST['room']]
        cursor.execute(query, args)
        mydb.commit()
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    return render(request,'session_form.html')
def session_info(request):
    S = session()
    sessions = []
    if request.method=='POST':
        sessionID = request.POST['sessionID']
        tutorID = request.POST['tutorID']
        sectionID = request.POST['sectionID']
        if(request.POST['session_time']=='' or request.POST['session_time']=='*'):
            session_time = request.POST['session_time']
            f = 0
        else:
            session_time = datetime.datetime.strptime(request.POST['session_time'],"%Y-%m-%d %H:%M:%S")
            f =1
        building = request.POST['building']
        room = request.POST['room']
        
        mydb = mysql.connector.connect(
        host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "SELECT * FROM sessions"
        cursor.execute(query)
        for result in cursor.fetchall():
            if(str(result['sessionID'])==sessionID or sessionID=='' or sessionID=='*'):
                if (str(result['tutorID'])==tutorID or tutorID ==''or tutorID =='*'):
                    if(str(result['sectionID'])==sectionID or sectionID ==''or sectionID =='*'):
                        if((f==1 and result['session_time']==session_time) or (f==0 and (session_time=='' or session_time =='*'))):
                            if(result['building']==building or building=='' or building =='*'):
                                if(result['room']==room or room == '' or room=='*'):
                                    sessions.append({'sessionID':result['sessionID'],'tutorID':result['tutorID'],'sectionID':result['sectionID'],'sessionTime': result['session_time'],'building' : result['building'],'room': result['room']})
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    context = {'Sessions':sessions}
    return render(request,'session_info.html',context) 
def student_query(request):
    return render(request,'student_query.html')
def student_form(request):
    if request.method =='POST':
        print(request.POST)
        mydb = mysql.connector.connect(
                host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor()
        query = "INSERT INTO students(studentID, name, email, gradYear) VALUES(%s, %s, %s, %s)"
        args = [int(request.POST['studentID']),request.POST['name'],request.POST['email'],int(request.POST['gradYear'])]
        cursor.execute(query, args)
        mydb.commit()
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    return render(request,'student_form.html')
def student_info(request):
    S = student()
    students = []
    if request.method=='POST':
        studentID = request.POST['studentID']
        name = request.POST['name']
        email = request.POST['email']
        gradYear = request.POST['gradYear']
        mydb = mysql.connector.connect(
            host='localhost',
            user='btodd',
            password='Seahawksbdrizzle1',
            database='cs317'
        )
        print()
        cursor = mydb.cursor(dictionary=True)
        query = "SELECT * FROM students"
        cursor.execute(query)
        for result in cursor.fetchall():
                print(result)
                if (str(result['studentID'])==studentID or studentID ==''or studentID =='*'):
                    if(result['name']==name or name ==''or name =='*'):
                        if(result['email']==email or email=='' or email =='*'):
                            if(str(result['gradYear'])==gradYear or gradYear=='' or gradYear =='*'):
                                students.append({'studentID':result['studentID'],'name':result['name'],'email':result['email'],'gradYear' : result['gradYear']})
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    context = {'Students':students}
    return render(request,'student_info.html',context)        
def subject_query(request):
    return render(request,'subject_query.html')
def subject_form(request):
    if request.method =='POST':
        print(request.POST)
        mydb = mysql.connector.connect(
                host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "INSERT INTO subjects(classID, courseNum, name, credits) VALUES(%s, %s, %s, %s)"
        args = [int(request.POST['classID']),request.POST['courseNum'],request.POST['name'],int(request.POST['credits'])]
        cursor.execute(query, args)
        mydb.commit()
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    return render(request,'subject_form.html')
def subject_info(request):
    S = subject()
    subjects = []
    if request.method=='POST':
        classID = request.POST['classID']
        courseNum=request.POST['courseNum']
        name = request.POST['name']
        credits = request.POST['credits']
        mydb = mysql.connector.connect(
                host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "SELECT * FROM subjects"
        cursor.execute(query)
        for result in cursor.fetchall():
                if (str(result['classID'])==classID or classID ==''or classID =='*'):
                    if(result['courseNum']==courseNum or courseNum ==''or courseNum =='*'):
                        if(result['name']==name or name=='' or name =='*'):
                            if(str(result['credits'])==credits or credits=='' or credits =='*'):
                                subjects.append({'classID':result['classID'],'course_num':result['courseNum'],'name':result['name'],'credits': result['credits']})
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    context = {'Subjects':subjects}
    return render(request,'subject_info.html',context)            
def teachers_query(request):
    return render(request,'teachers_query.html')
def teachers_form(request):
    if request.method=='POST':
        mydb = mysql.connector.connect(
                host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "INSERT INTO teachers(employeeID, name, email) VALUES(%s, %s, %s)"
        args = [int(request.POST['employeeID']),request.POST['name'],request.POST['email']]
        cursor.execute(query, args)
        mydb.commit()
        if mydb.is_connected():
            cursor.close()
            mydb.close()
    return render(request,'teachers_form.html')

def teacher_info(request):
    T = teacher()
    teachers = []
    if request.method=='POST':
        employeeID = request.POST['employeeID']
        name = request.POST['name']
        email = request.POST['email']
        mydb = mysql.connector.connect(
                host='localhost',
                user='btodd',
                password='Seahawksbdrizzle1',
                database='cs317'
        )
        cursor = mydb.cursor(dictionary=True)
        query = "SELECT * FROM teachers"
        cursor.execute(query)
        for result in cursor.fetchall():
                if (str(result['employeeID'])==employeeID or employeeID ==''or employeeID =='*'):
                    if(result['name']==name or name ==''or name =='*'):
                        if(result['email']==email or email=='' or email =='*'):
                            teachers.append({'employeeID':result['employeeID'],'name':result['name'],'email':result['email']})
        if mydb.is_connected():
            cursor.close()
            mydb.close()            
    context = {'Teachers':teachers}
    return render(request,'teachers_info.html',context)