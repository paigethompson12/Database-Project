from django import forms
from .models import *

class appointmentForm(forms.ModelForm):
    class Meta:
        model = appointments
        fields = ['appointmentID','tutorID','studentID','sectionID','appointment_time','building','room',]
        labels= {'appointmentID':'Appointment ID','tutorID':'Tutor ID','studentID':'Student ID','sectionID':'Section ID','appointment_time':'Appointment Time','building':'Building','room':'Room'}
class instructorForm(forms.ModelForm):
    class Meta:
        model = instructor
        fields = ['classID','sectionID','tutorID','employeeID']
        labels={'classID':'Class ID','sectionID':'Section ID','tutorID':'Tutor ID','employeeID':'Employee ID'}
class sessionForm(forms.ModelForm):
    class Meta:
        model = session
        fields = ['sessionID','sectionID','tutorID','sessionTime','building','room']
        labels={'sessionID':'Session ID','sectionID':'Section ID','tutorID':'Tutor ID','sessionTime':'Session Time','building':'Building','room':'Room'}
class studentForm(forms.ModelForm):
    class Meta:
        model = student
        fields = ['studentID','name','email','gradYear']
        labels={'studentID':'Student ID','name':'Name','email':'Email','gradYear':'Grad Year'}
class subjectForm(forms.ModelForm):
    class Meta:
        model = subject
        fields = ['classID','course_num','name','credits']
        labels={'classID':'Class ID','course_num':'Course Number','name':'Name','credits':'Credits'}
class teacherForm(forms.ModelForm):
    class Meta:
        model = teacher
        fields = ['employeeID','name','email']
        labels={'employeeID':'Employee ID','name':'Name','email':'Email'}


           
           
           